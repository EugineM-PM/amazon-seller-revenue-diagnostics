import * as XLSX from 'xlsx';
import { CategorySummary, Currency, ProductItem, SellerHealthData, TimePeriod } from '../types/seller';
import { PRODUCTS_DATA_BY_PERIOD, CATEGORIES_DATA_BY_PERIOD, INITIAL_SELLER_HEALTH } from '../data/mockData';

interface ExportExcelOptions {
  timePeriod: TimePeriod;
  currency: Currency;
  products: ProductItem[];
  categories: CategorySummary[];
  sellerHealth: SellerHealthData;
}

/**
 * Generates and downloads a multi-sheet, executive-grade Excel (.xlsx) workbook
 * containing all 10 products across 5 categories, 3 time horizons, keyword intelligence,
 * and executive diagnosis summaries.
 */
export function exportToExcel({
  timePeriod,
  currency,
  products,
  categories,
  sellerHealth,
}: ExportExcelOptions): void {
  const wb = XLSX.utils.book_new();
  const timestamp = new Date().toISOString().split('T')[0];

  // ==========================================
  // SHEET 1: Executive Portfolio Summary
  // ==========================================
  const summaryData = [
    { Parameter: 'Report Name', Value: 'AuraSeller Amazon 3P Executive Diagnostics' },
    { Parameter: 'Marketplace', Value: 'Amazon UAE (Amazon.ae)' },
    { Parameter: 'Report Generation Date', Value: timestamp },
    { Parameter: 'Active Time Period', Value: timePeriod.toUpperCase() },
    { Parameter: 'Reporting Currency', Value: currency },
    { Parameter: '-----------------------------', Value: '-----------------------------' },
    { Parameter: 'Overall Seller Health Score', Value: `${sellerHealth.overallScore} / 100` },
    { Parameter: 'Previous Period Score', Value: `${sellerHealth.previousScore} / 100` },
    { Parameter: 'Score Delta', Value: `${sellerHealth.scoreDelta > 0 ? '+' : ''}${sellerHealth.scoreDelta} pts` },
    { Parameter: 'Total Catalog GMV (Revenue)', Value: `${currency} ${sellerHealth.totalRevenue.toLocaleString()}` },
    { Parameter: 'Revenue Growth / Deceleration', Value: `${sellerHealth.revenueDeltaPercent > 0 ? '+' : ''}${sellerHealth.revenueDeltaPercent}%` },
    { Parameter: 'Immediate Revenue At Risk', Value: `${currency} ${sellerHealth.revenueAtRisk.toLocaleString()}` },
    { Parameter: 'Active Critical Issues', Value: sellerHealth.issuesCount },
    { Parameter: 'Primary Portfolio Concern', Value: sellerHealth.primaryConcern },
    { Parameter: '-----------------------------', Value: '-----------------------------' },
    { Parameter: '1. WHAT HAPPENED', Value: `Net GMV pacing at ${currency} ${sellerHealth.totalRevenue.toLocaleString()} (${sellerHealth.revenueDeltaPercent}%) with 18 hours of Buy Box loss, search visibility decay on head terms, and inventory depleted to 8.2 DOC on flagship ASIN.` },
    { Parameter: '2. WHY (ROOT CAUSE)', Value: 'Compounding algorithmic chain reaction: 3P competitor automated undercuts triggered Buy Box loss, which suppressed organic A9 ranking and conversion velocity, while customs delay at DXB3 created acute stockout vulnerability.' },
    { Parameter: '3. NEXT BEST ACTION', Value: '1) Re-anchor Buy Box with 15-min automated repricer rule at AED 1,075. 2) Deploy 5% clippable voucher badge. 3) Dispatch 350-unit priority air freight FBA inbound transfer to prevent OOS delisting.' },
  ];

  const wsSummary = XLSX.utils.json_to_sheet(summaryData);
  wsSummary['!cols'] = [{ wch: 32 }, { wch: 95 }];
  XLSX.utils.book_append_sheet(wb, wsSummary, 'Executive Summary');

  // ==========================================
  // SHEET 2: 10 Products Master Details
  // ==========================================
  const productRows = products.map((p, idx) => ({
    '#': idx + 1,
    'ASIN': p.asin,
    'SKU': p.sku,
    'Product Name': p.name,
    'Category': p.category.toUpperCase(),
    [`Current Price (${currency})`]: p.currentPrice,
    [`Lowest Competitor (${currency})`]: p.lowestCompetitorPrice,
    [`Price Delta (${currency})`]: p.currentPrice - p.lowestCompetitorPrice,
    [`GMV Revenue (${currency})`]: p.revenue,
    'Revenue Growth %': `${p.revenueChangePct > 0 ? '+' : ''}${p.revenueChangePct}%`,
    [`Revenue At Risk (${currency})`]: p.revenueAtRisk,
    'Units Sold': p.unitsSold,
    'Orders': p.orders,
    'Return Rate %': `${p.returnRate}%`,
    'Buy Box Win Rate %': `${p.buyBoxPct}%`,
    'Previous Buy Box %': `${p.prevBuyBoxPct}%`,
    'Buy Box PP Change': `${p.buyBoxPPChange > 0 ? '+' : ''}${p.buyBoxPPChange} PP`,
    'Buy Box Alert Status': p.buyBoxAlert.toUpperCase(),
    'Conversion Rate %': `${p.currentConversionPct}%`,
    'Historical Conversion %': `${p.historicalConversionPct}%`,
    'Product Detail Page Views': p.productViews,
    'Add To Carts': p.addToCarts,
    'Purchases': p.purchases,
    'Current Stock Units': p.currentStockUnits,
    'Daily Velocity (units/day)': p.dailySellThroughRate,
    'Days of Cover (DOC)': p.daysOfCover,
    'Inventory Alert Status': p.inventoryAlert.toUpperCase(),
    'Organic Search Rank': `#${p.overallSearchRank}`,
    'Primary Driver': p.diagnosisSummary.primaryDriver,
    'Recommended Action': p.diagnosisSummary.actionItems[0]?.title || 'Monitor metrics',
  }));

  const wsProducts = XLSX.utils.json_to_sheet(productRows);
  wsProducts['!cols'] = [
    { wch: 4 }, { wch: 14 }, { wch: 18 }, { wch: 45 }, { wch: 18 },
    { wch: 16 }, { wch: 18 }, { wch: 16 }, { wch: 18 }, { wch: 16 },
    { wch: 18 }, { wch: 12 }, { wch: 10 }, { wch: 14 }, { wch: 16 },
    { wch: 16 }, { wch: 16 }, { wch: 18 }, { wch: 16 }, { wch: 18 },
    { wch: 22 }, { wch: 14 }, { wch: 12 }, { wch: 18 }, { wch: 18 },
    { wch: 16 }, { wch: 18 }, { wch: 16 }, { wch: 40 }, { wch: 40 }
  ];
  XLSX.utils.book_append_sheet(wb, wsProducts, '10 Products Master');

  // ==========================================
  // SHEET 3: 5 Categories Performance
  // ==========================================
  const categoryRows = categories.map((c) => ({
    'Category ID': c.id,
    'Category Name': c.name,
    'Products Count': c.productCount,
    [`Total GMV (${currency})`]: c.totalGmv,
    'GMV Growth %': `${c.gmvGrowthPct > 0 ? '+' : ''}${c.gmvGrowthPct}%`,
    'Avg Buy Box Win %': `${c.avgBuyBoxPct}%`,
    'Critical Stockout Risk SKUs': c.stockoutRiskCount,
  }));

  const wsCategories = XLSX.utils.json_to_sheet(categoryRows);
  wsCategories['!cols'] = [
    { wch: 16 }, { wch: 28 }, { wch: 16 }, { wch: 20 }, { wch: 16 }, { wch: 18 }, { wch: 24 }
  ];
  XLSX.utils.book_append_sheet(wb, wsCategories, '5 Categories Summary');

  // ==========================================
  // SHEET 4: Keyword Intelligence & Search Rankings
  // ==========================================
  const keywordRows: any[] = [];
  products.forEach((p) => {
    p.searchTerms.forEach((st) => {
      keywordRows.push({
        'Product ASIN': p.asin,
        'Product Name': p.name,
        'Category': p.category.toUpperCase(),
        'Search Keyword': st.term,
        'Monthly Search Volume': st.searchVolume,
        'Current Rank': `#${st.currentRank}`,
        'Previous Rank': `#${st.prevRank}`,
        'Rank Shift': `${st.change > 0 ? '+' : ''}${st.change}`,
        'Rank Alert': st.alert.toUpperCase(),
        'Opportunity Keyword': st.isOpportunity ? 'YES (High Potential)' : 'Core Term',
        [`Revenue Opportunity (${currency})`]: Math.abs(st.lostGainedRevenue),
      });
    });
  });

  const wsKeywords = XLSX.utils.json_to_sheet(keywordRows);
  wsKeywords['!cols'] = [
    { wch: 14 }, { wch: 38 }, { wch: 18 }, { wch: 35 }, { wch: 20 },
    { wch: 14 }, { wch: 14 }, { wch: 12 }, { wch: 14 }, { wch: 22 }, { wch: 24 }
  ];
  XLSX.utils.book_append_sheet(wb, wsKeywords, 'Search Keyword Intelligence');

  // ==========================================
  // SHEET 5: Multi-Period Comparison (Weekly vs Monthly vs 90 Days)
  // ==========================================
  const comparisonRows: any[] = [];
  const weeklyProducts = PRODUCTS_DATA_BY_PERIOD.weekly;
  const monthlyProducts = PRODUCTS_DATA_BY_PERIOD.monthly;
  const quarterlyProducts = PRODUCTS_DATA_BY_PERIOD['90days'];

  weeklyProducts.forEach((wp, idx) => {
    const mp = monthlyProducts[idx] || wp;
    const qp = quarterlyProducts[idx] || wp;

    comparisonRows.push({
      'ASIN': wp.asin,
      'Product Name': wp.name,
      'Category': wp.category.toUpperCase(),
      [`Weekly GMV (${currency})`]: wp.revenue,
      'Weekly Growth %': `${wp.revenueChangePct}%`,
      'Weekly Buy Box %': `${wp.buyBoxPct}%`,
      'Weekly DOC (Days)': wp.daysOfCover,
      [`Monthly GMV (${currency})`]: mp.revenue,
      'Monthly Growth %': `${mp.revenueChangePct}%`,
      'Monthly Buy Box %': `${mp.buyBoxPct}%`,
      'Monthly DOC (Days)': mp.daysOfCover,
      [`90-Days GMV (${currency})`]: qp.revenue,
      '90-Days Growth %': `${qp.revenueChangePct}%`,
      '90-Days Buy Box %': `${qp.buyBoxPct}%`,
      '90-Days DOC (Days)': qp.daysOfCover,
    });
  });

  const wsComparison = XLSX.utils.json_to_sheet(comparisonRows);
  wsComparison['!cols'] = [
    { wch: 14 }, { wch: 38 }, { wch: 18 },
    { wch: 18 }, { wch: 16 }, { wch: 16 }, { wch: 16 },
    { wch: 18 }, { wch: 16 }, { wch: 16 }, { wch: 16 },
    { wch: 18 }, { wch: 16 }, { wch: 16 }, { wch: 16 }
  ];
  XLSX.utils.book_append_sheet(wb, wsComparison, 'Multi-Period Horizons');

  // Generate binary XLSX file and trigger instant download in browser
  const filename = `AuraSeller_Catalog_Diagnostics_${timePeriod}_${timestamp}.xlsx`;
  XLSX.writeFile(wb, filename);
}
