import { SupportedLanguage } from '../types/seller';

export interface DashboardTranslations {
  // Brand & Header
  brandTitle: string;
  marketplaceSubtitle: string;
  tagline: string;
  downloadExcel: string;
  rootCauseDiagnosis: string;
  sellerGenie: string;
  live3dAi: string;
  voiceDiagnostics: string;
  categoryLabel: string;
  productLabel: string;
  allProducts: string;
  northStarLabel: string;
  northStarValue: string;
  timeWeekly: string;
  timeMonthly: string;
  time90days: string;

  // Nav tabs
  tabAll: string;
  tabSales: string;
  tabBuyBox: string;
  tabConversion: string;
  tabPricing: string;
  tabSearch: string;
  tabInventory: string;

  // Seller Health Card
  sellerHealthTitle: string;
  weightedIndexPill: string;
  sellerHealthSubtitle: string;
  diagnoseWhy: string;
  statusHealthy: string;
  statusActionNeeded: string;
  statusCritical: string;
  whyScoreButton: string;
  totalMarketplaceRev: string;
  vsPrevPeriod: string;
  revAtRisk: string;
  issuesNeedAttention: string;
  primaryConcernPrefix: string;
  whatsDrivingChange: string;
  hoverToInspect: string;
  clickDriverToJump: string;
  primaryLoss: string;

  // Revenue decomposition
  doubleClickRevenueHint: string;
  revenueDecompTitle: string;
  revenueFormula: string;
  why12DropTitle: string;

  // 3-Point Summary Cards
  executiveSummary: string;
  diagnosticBrief: string;
  whatHappened: string;
  whyRootCause: string;
  nextBestAction: string;
  plainSellerWordsTitle: string;
  plainSellerWordsBadge: string;
  observedImpact: string;
  primaryDriver: string;
  prescriptiveResolution: string;
  executeAction: string;

  // Drivers
  driverBuyBox: string;
  driverSearch: string;
  driverInventory: string;
  driverConversion: string;
  driverPricing: string;
}

export const TRANSLATIONS: Record<SupportedLanguage, DashboardTranslations> = {
  English: {
    brandTitle: 'AuraSeller',
    marketplaceSubtitle: 'Amazon 3P Intelligence · UAE Marketplace (Amazon.ae)',
    tagline: 'What Happened · Why It Happened · What Needs Attention',
    downloadExcel: 'Download Excel',
    rootCauseDiagnosis: 'Root Cause Diagnosis',
    sellerGenie: 'Seller Genie',
    live3dAi: 'Live 3D AI',
    voiceDiagnostics: 'Voice Diagnostics',
    categoryLabel: 'Category:',
    productLabel: 'Product:',
    allProducts: 'All Products (10 SKUs)',
    northStarLabel: 'North Star:',
    northStarValue: 'GMV per product by category',
    timeWeekly: 'Weekly',
    timeMonthly: 'Monthly',
    time90days: 'Last 90 Days',

    tabAll: 'All Modules',
    tabSales: 'Sales & North Star',
    tabBuyBox: 'Buy Box',
    tabConversion: 'Conversion Funnel',
    tabPricing: 'Pricing & Undercuts',
    tabSearch: 'Search Visibility',
    tabInventory: 'Inventory (DOC)',

    sellerHealthTitle: 'Seller Revenue Health',
    weightedIndexPill: 'Weighted Index (5 Pillars × 20%)',
    sellerHealthSubtitle: 'Synthesized from Amazon Seller Central performance and competitive algorithms',
    diagnoseWhy: 'Diagnose Why',
    statusHealthy: 'Healthy',
    statusActionNeeded: 'Action Needed',
    statusCritical: 'Critical',
    whyScoreButton: 'Why 78 pts? Formula Breakdown',
    totalMarketplaceRev: 'Total Marketplace Revenue',
    vsPrevPeriod: 'vs prev period',
    revAtRisk: 'Revenue at Risk',
    issuesNeedAttention: 'issues need attention',
    primaryConcernPrefix: 'Primary:',
    whatsDrivingChange: "What's Driving The Change?",
    hoverToInspect: 'Hover pillar to inspect',
    clickDriverToJump: 'Click driver to jump directly to module ↓',
    primaryLoss: 'Primary Loss',

    doubleClickRevenueHint: '💡 Double-click for Orders × Price math & why 12% drop happened',
    revenueDecompTitle: 'Marketplace Revenue Decomposition: Orders × Price',
    revenueFormula: 'Total Revenue = Total Orders × Average Selling Price (ASP)',
    why12DropTitle: 'Why Did the 12% Drop Happen?',

    executiveSummary: 'Executive Summary',
    diagnosticBrief: 'Diagnostic Brief',
    whatHappened: '1. What Happened',
    whyRootCause: '2. Why (Root Cause)',
    nextBestAction: '3. Next Best Action',
    plainSellerWordsTitle: 'Simplified Explanation',
    plainSellerWordsBadge: 'Simple English',
    observedImpact: 'Observed Impact:',
    primaryDriver: 'Primary Driver:',
    prescriptiveResolution: 'Prescriptive resolution',
    executeAction: 'Execute Action',

    driverBuyBox: 'Buy Box Performance',
    driverSearch: 'Search Visibility',
    driverInventory: 'Healthy Inventory Stock Level',
    driverConversion: 'Conversion Rate',
    driverPricing: 'Competitive Pricing',
  },

  'Telugu (తెలుగు)': {
    brandTitle: 'ఔరాసెల్లర్ (AuraSeller)',
    marketplaceSubtitle: 'అమెజాన్ 3P ఇంటెలిజెన్స్ · UAE మార్కెట్ (Amazon.ae)',
    tagline: 'ఏమి జరిగింది · ఎందుకు జరిగింది · తక్షణ చర్యలు',
    downloadExcel: 'ఎక్సెల్ డౌన్‌లోడ్',
    rootCauseDiagnosis: 'రూట్ కాజ్ విశ్లేషణ',
    sellerGenie: 'సెల్లర్ జీనీ',
    live3dAi: 'లైవ్ 3D AI',
    voiceDiagnostics: 'వాయిస్ సలహాదారు',
    categoryLabel: 'కేటగిరీ:',
    productLabel: 'ఉత్పత్తి:',
    allProducts: 'అన్ని ఉత్పత్తులు (10 SKUs)',
    northStarLabel: 'ప్రధాన లక్ష్యం:',
    northStarValue: 'కేటగిరీ వారీగా GMV రాబడి',
    timeWeekly: 'వారం వారీ',
    timeMonthly: 'నెల వారీ',
    time90days: 'గత 90 రోజులు',

    tabAll: 'అన్ని మాడ్యూల్స్',
    tabSales: 'సేల్స్ & నార్త్ స్టార్',
    tabBuyBox: 'బై బాక్స్ (Buy Box)',
    tabConversion: 'కన్వర్షన్ ఫన్నెల్',
    tabPricing: 'ధరల పోటీ & తగ్గింపులు',
    tabSearch: 'సెర్చ్ విజిబిలిటీ',
    tabInventory: 'ఇన్వెంటరీ స్టాక్ (DOC)',

    sellerHealthTitle: 'సెల్లర్ రాబడి ఆరోగ్యం',
    weightedIndexPill: 'వెయిటెడ్ ఇండెక్స్ (5 స్తంభాలు × 20%)',
    sellerHealthSubtitle: 'అమెజాన్ సేల్స్ మరియు పోటీదారుల అల్గారిథమ్స్ విశ్లేషణ',
    diagnoseWhy: 'కారణం తెలుసుకోండి',
    statusHealthy: 'ఆరోగ్యకరం',
    statusActionNeeded: 'చర్య అవసరం',
    statusCritical: 'ప్రమాదకరం',
    whyScoreButton: '78 పాయింట్లు ఎందుకు? లెక్కింపు వివరణ',
    totalMarketplaceRev: 'మొత్తం మార్కెట్ ప్లేస్ రాబడి',
    vsPrevPeriod: 'గత కాలంతో పోలిస్తే',
    revAtRisk: 'రిస్క్ లో ఉన్న రాబడి',
    issuesNeedAttention: 'సమస్యలు పరిష్కరించాలి',
    primaryConcernPrefix: 'ప్రధాన సమస్య:',
    whatsDrivingChange: 'మార్పుకు ప్రధాన కారణాలు ఏమిటి?',
    hoverToInspect: 'వివరాలకు తాకండి',
    clickDriverToJump: 'మాడ్యూల్‌కు వెళ్లడానికి క్లిక్ చేయండి ↓',
    primaryLoss: 'ప్రధాన నష్టం',

    doubleClickRevenueHint: '💡 ఆర్డర్లు × ధర లెక్కలు & 12% తగ్గుదల కారణం చూడటానికి డబుల్ క్లిక్ చేయండి',
    revenueDecompTitle: 'మార్కెట్‌ప్లేస్ రాబడి సమీకరణం: ఆర్డర్లు × ధర',
    revenueFormula: 'మొత్తం రాబడి = మొత్తం ఆర్డర్లు × సగటు అమ్మకపు ధర (ASP)',
    why12DropTitle: '12% రాబడి ఎందుకు తగ్గింది?',

    executiveSummary: 'ఎగ్జిక్యూటివ్ సారాంశం',
    diagnosticBrief: 'నిర్ధారణ నివేదిక',
    whatHappened: '1. ఏమి జరిగింది?',
    whyRootCause: '2. ఎందుకు జరిగింది (మూల కారణం)?',
    nextBestAction: '3. మీరు చేయాల్సిన తక్షణ చర్య',
    plainSellerWordsTitle: 'సరళమైన వివరణ (Simplified Explanation)',
    plainSellerWordsBadge: 'తెలుగు వివరణ',
    observedImpact: 'గమనించిన ప్రభావం:',
    primaryDriver: 'ప్రధాన డ్రైవర్:',
    prescriptiveResolution: 'సిఫార్సు పరిష్కారం',
    executeAction: 'చర్య అమలు చేయండి',

    driverBuyBox: 'బై బాక్స్ పనితీరు',
    driverSearch: 'సెర్చ్ ర్యాంకింగ్ & విజిబిలిటీ',
    driverInventory: 'ఇన్వెంటరీ స్టాక్ స్థాయి',
    driverConversion: 'కన్వర్షన్ రేటు',
    driverPricing: 'పోటీ ధరల నిర్వహణ',
  },

  'Tamil (தமிழ்)': {
    brandTitle: 'அவுராசெல்லர் (AuraSeller)',
    marketplaceSubtitle: 'அமேசான் 3P நுண்ணறிவு · UAE சந்தை (Amazon.ae)',
    tagline: 'என்ன நடந்தது · ஏன் நடந்தது · உடனடி தீர்வுகள்',
    downloadExcel: 'எக்செல் பதிவிறக்கம்',
    rootCauseDiagnosis: 'காரண பகுப்பாய்வு',
    sellerGenie: 'செல்லர் ஜீனி',
    live3dAi: 'லைவ் 3D AI',
    voiceDiagnostics: 'குரல் வழிகாட்டி',
    categoryLabel: 'வகை:',
    productLabel: 'தயாரிப்பு:',
    allProducts: 'அனைத்து தயாரிப்புகள் (10 SKUs)',
    northStarLabel: 'முக்கிய இலக்கு:',
    northStarValue: 'வகை வாரியாக GMV வருவாய்',
    timeWeekly: 'வாராந்திர',
    timeMonthly: 'மாதாந்திர',
    time90days: 'கடந்த 90 நாட்கள்',

    tabAll: 'அனைத்து பிரிவுகள்',
    tabSales: 'விற்பனை & வருவாய்',
    tabBuyBox: 'பை பாக்ஸ் (Buy Box)',
    tabConversion: 'மாற்ற புனல் (Conversion)',
    tabPricing: 'விலை நிர்ணயம்',
    tabSearch: 'தேடல் தெரிவுநிலை',
    tabInventory: 'சரக்கு இருப்பு (DOC)',

    sellerHealthTitle: 'விற்பனையாளர் வருவாய் நலம்',
    weightedIndexPill: 'மதிப்பீட்டுக் குறியீடு (5 தூண்கள் × 20%)',
    sellerHealthSubtitle: 'அமேசான் விற்பனை மற்றும் போட்டி அல்காரிதம்களின் தொகுப்பு',
    diagnoseWhy: 'காரணம் அறிக',
    statusHealthy: 'நலமாக உள்ளது',
    statusActionNeeded: 'நடவடிக்கை தேவை',
    statusCritical: 'முக்கிய எச்சரிக்கை',
    whyScoreButton: '78 புள்ளிகள் ஏன்? கணக்கீட்டு விளக்கம்',
    totalMarketplaceRev: 'மொத்த சந்தை வருவாய்',
    vsPrevPeriod: 'முந்தைய காலத்துடன்',
    revAtRisk: 'ஆபத்தில் உள்ள வருவாய்',
    issuesNeedAttention: 'கவனிக்க வேண்டிய சிக்கல்கள்',
    primaryConcernPrefix: 'முக்கிய கவலை:',
    whatsDrivingChange: 'மாற்றத்திற்கு என்ன காரணம்?',
    hoverToInspect: 'ஆராய சுட்டியை வைக்கவும்',
    clickDriverToJump: 'பிரிவுக்கு செல்ல கிளிக் செய்க ↓',
    primaryLoss: 'முக்கிய இழப்பு',

    doubleClickRevenueHint: '💡 ஆர்டர்கள் × விலை கணக்கீடு & 12% வீழ்ச்சியை அறிய இருமுறை கிளிக் செய்க',
    revenueDecompTitle: 'வருவாய் கணக்கீடு: ஆர்டர்கள் × விலை',
    revenueFormula: 'மொத்த வருவாய் = ஆர்டர்கள் எண்ணிக்கை × சராசரி விலை (ASP)',
    why12DropTitle: '12% வருவாய் வீழ்ச்சி ஏன் ஏற்பட்டது?',

    executiveSummary: 'நிர்வாக சுருக்கம்',
    diagnosticBrief: 'பகுப்பாய்வு குறிப்பு',
    whatHappened: '1. என்ன நடந்தது?',
    whyRootCause: '2. ஏன் நடந்தது (மூல காரணம்)?',
    nextBestAction: '3. நீங்கள் செய்ய வேண்டிய சிறந்த நடவடிக்கை',
    plainSellerWordsTitle: 'சுலபமான விளக்கம் (Simplified Explanation)',
    plainSellerWordsBadge: 'தமிழ் விளக்கம்',
    observedImpact: 'கண்டறியப்பட்ட தாக்கம்:',
    primaryDriver: 'முக்கிய இயக்கி:',
    prescriptiveResolution: 'பரிந்துரைக்கப்பட்ட தீர்வு',
    executeAction: 'நடவடிக்கை எடு',

    driverBuyBox: 'பை பாக்ஸ் செயல்பாடு',
    driverSearch: 'தேடல் தெரிவுநிலை',
    driverInventory: 'ஆரோக்கியமான சரக்கு இருப்பு',
    driverConversion: 'விற்பனை மாற்ற விகிதம்',
    driverPricing: 'போட்டி விலை நிர்ணயம்',
  },

  'Hindi (हिंदी)': {
    brandTitle: 'ऑरासेलर (AuraSeller)',
    marketplaceSubtitle: 'अमेज़न 3P इंटेलिजेंस · UAE मार्केटप्लेस (Amazon.ae)',
    tagline: 'क्या हुआ · क्यों हुआ · तुरंत क्या कदम उठाएं',
    downloadExcel: 'एक्सेल डाउनलोड',
    rootCauseDiagnosis: 'रूट कॉज़ डायग्नोसिस',
    sellerGenie: 'सेलर जिनी',
    live3dAi: 'लाइव 3D AI',
    voiceDiagnostics: 'वॉइस एडवाइजर',
    categoryLabel: 'श्रेणी:',
    productLabel: 'उत्पाद:',
    allProducts: 'सभी उत्पाद (10 SKUs)',
    northStarLabel: 'नॉर्थ स्टार:',
    northStarValue: 'श्रेणी अनुसार GMV राजस्व',
    timeWeekly: 'साप्ताहिक',
    timeMonthly: 'मासिक',
    time90days: 'पिछले 90 दिन',

    tabAll: 'सभी मॉड्यूल्स',
    tabSales: 'बिक्री और राजस्व',
    tabBuyBox: 'बाय बॉक्स (Buy Box)',
    tabConversion: 'कन्वर्शन फ़नल',
    tabPricing: 'प्रतिस्पर्धी मूल्य',
    tabSearch: 'सर्च विजिबिलिटी',
    tabInventory: 'इन्वेंट्री स्टॉक (DOC)',

    sellerHealthTitle: 'सेलर रेवेन्यू हेल्थ',
    weightedIndexPill: 'भारित सूचकांक (5 स्तंभ × 20%)',
    sellerHealthSubtitle: 'अमेज़न सेलर सेंट्रल परफॉरमेंस और एल्गोरिदम का विश्लेषण',
    diagnoseWhy: 'कारण जानें',
    statusHealthy: 'स्वस्थ',
    statusActionNeeded: 'कार्रवाई आवश्यक',
    statusCritical: 'गंभीर',
    whyScoreButton: '78 अंक क्यों? गणना का विवरण',
    totalMarketplaceRev: 'कुल मार्केटप्लेस राजस्व',
    vsPrevPeriod: 'पिछली अवधि की तुलना में',
    revAtRisk: 'जोखिम में राजस्व',
    issuesNeedAttention: 'समस्याओं पर ध्यान दें',
    primaryConcernPrefix: 'मुख्य चिंता:',
    whatsDrivingChange: 'इस बदलाव का मुख्य कारण क्या है?',
    hoverToInspect: 'विवरण के लिए माउस लाएं',
    clickDriverToJump: 'संबंधित मॉड्यूल पर जाने के लिए क्लिक करें ↓',
    primaryLoss: 'प्रमुख नुकसान',

    doubleClickRevenueHint: '💡 ऑर्डर्स × मूल्य गणित और 12% गिरावट देखने के लिए डबल क्लिक करें',
    revenueDecompTitle: 'राजस्व समीकरण: ऑर्डर्स संख्या × औसत मूल्य',
    revenueFormula: 'कुल राजस्व = कुल ऑर्डर्स × औसत बिक्री मूल्य (ASP)',
    why12DropTitle: '12% की गिरावट क्यों हुई?',

    executiveSummary: 'कार्यकारी सारांश',
    diagnosticBrief: 'डायग्नोस्टिक रिपोर्ट',
    whatHappened: '1. क्या हुआ?',
    whyRootCause: '2. यह क्यों हुआ (मूल कारण)?',
    nextBestAction: '3. अगला सर्वश्रेष्ठ कदम',
    plainSellerWordsTitle: 'सरल व्याख्या (Simplified Explanation)',
    plainSellerWordsBadge: 'हिंदी विवरण',
    observedImpact: 'देखा गया प्रभाव:',
    primaryDriver: 'प्राथमिक ड्राइवर:',
    prescriptiveResolution: 'सुझाया गया उपाय',
    executeAction: 'कार्रवाई करें',

    driverBuyBox: 'बाय बॉक्स परफॉरमेंस',
    driverSearch: 'सर्च विजिबिलिटी',
    driverInventory: 'इन्वेंट्री स्टॉक स्तर',
    driverConversion: 'कन्वर्शन दर',
    driverPricing: 'प्रतिस्पर्धी मूल्य निर्धारण',
  },

  'Malayalam (മലയാളം)': {
    brandTitle: 'ഔറാസെല്ലർ (AuraSeller)',
    marketplaceSubtitle: 'ആമസോൺ 3P ഇന്റലിജൻസ് · UAE മാർക്കറ്റ് (Amazon.ae)',
    tagline: 'എന്തു സംഭവിച്ചു · എന്തുകൊണ്ട് സംഭവിച്ചു · പരിഹാരങ്ങൾ',
    downloadExcel: 'എക്സെൽ ഡൗൺലോഡ്',
    rootCauseDiagnosis: 'റൂട്ട് കോസ് പരിശോധന',
    sellerGenie: 'സെല്ലർ ജീനി',
    live3dAi: 'ലൈവ് 3D AI',
    voiceDiagnostics: 'വോയ്സ് അസിസ്റ്റന്റ്',
    categoryLabel: 'വിഭാഗം:',
    productLabel: 'ഉൽപ്പന്നം:',
    allProducts: 'എല്ലാ ഉൽപ്പന്നങ്ങളും (10 SKUs)',
    northStarLabel: 'പ്രധാന ലക്ഷ്യം:',
    northStarValue: 'വിഭാഗം തിരിച്ചുള്ള GMV വരുമാനം',
    timeWeekly: 'പ്രതിവാരം',
    timeMonthly: 'പ്രതിമാസം',
    time90days: 'കഴിഞ്ഞ 90 ദിവസങ്ങൾ',

    tabAll: 'എല്ലാ മൊഡ്യൂളുകളും',
    tabSales: 'വിൽപ്പനയും വരുമാനവും',
    tabBuyBox: 'ബൈ ബോക്സ് (Buy Box)',
    tabConversion: 'കൺവേർഷൻ ഫണൽ',
    tabPricing: 'മത്സര വിലനിർണ്ണയം',
    tabSearch: 'തിരച്ചിൽ സാന്നിധ്യം',
    tabInventory: 'ഇൻവെന്ററി സ്റ്റോക്ക് (DOC)',

    sellerHealthTitle: 'സെല്ലർ വരുമാന ആരോഗ്യം',
    weightedIndexPill: 'വെയ്റ്റഡ് ഇൻഡക്സ് (5 സ്തംഭങ്ങൾ × 20%)',
    sellerHealthSubtitle: 'ആമസോൺ സെല്ലർ പ്രകടനത്തിന്റെയും അൽഗോരിതങ്ങളുടെയും വിശകലനം',
    diagnoseWhy: 'കാരണം കണ്ടെത്തുക',
    statusHealthy: 'ആരോഗ്യം ഉള്ളത്',
    statusActionNeeded: 'നടപടി ആവശ്യമാണ്',
    statusCritical: 'ഗുരുതരം',
    whyScoreButton: '78 പോയിന്റുകൾ എന്തുകൊണ്ട്? കണക്കുകൂട്ടൽ',
    totalMarketplaceRev: 'ആകെ മാർക്കറ്റ് വരുമാനം',
    vsPrevPeriod: 'മുൻ കാലയളവുമായി താരതമ്യം',
    revAtRisk: 'അപകടസാധ്യതയുള്ള വരുമാനം',
    issuesNeedAttention: 'ശ്രദ്ധിക്കേണ്ട പ്രശ്നങ്ങൾ',
    primaryConcernPrefix: 'പ്രധാന ആശങ്ക:',
    whatsDrivingChange: 'മാറ്റത്തിന് പിന്നിലെ കാരണങ്ങൾ എന്തൊക്കെ?',
    hoverToInspect: 'കൂടുതൽ വിവരങ്ങൾക്ക് സ്പർശിക്കുക',
    clickDriverToJump: 'മൊഡ്യൂളിലേക്ക് പോകാൻ ക്ലിക്ക് ചെയ്യുക ↓',
    primaryLoss: 'പ്രധാന നഷ്ടം',

    doubleClickRevenueHint: '💡 ഓർഡറുകൾ × വില കണക്കുകളും 12% ഇടിവിന്റെ കാരണവും കാണാൻ ഇരട്ട ക്ലിക്ക് ചെയ്യുക',
    revenueDecompTitle: 'വരുമാന വിഭജനം: ഓർഡറുകൾ × വില',
    revenueFormula: 'ആകെ വരുമാനം = ഓർഡറുകൾ × ശരാശരി വിൽപന വില (ASP)',
    why12DropTitle: '12% ഇടിവ് എന്തുകൊണ്ട് സംഭവിച്ചു?',

    executiveSummary: 'എക്സിക്യൂട്ടീവ് സംഗ്രഹം',
    diagnosticBrief: 'ഡയഗ്നോസ്റ്റിക് കുറിപ്പ്',
    whatHappened: '1. എന്തു സംഭവിച്ചു?',
    whyRootCause: '2. എന്തുകൊണ്ട് സംഭവിച്ചു (കാരണം)?',
    nextBestAction: '3. ഉടൻ സ്വീകരിക്കേണ്ട മികച്ച നടപടി',
    plainSellerWordsTitle: 'ലളിതമായ വിവരണം (Simplified Explanation)',
    plainSellerWordsBadge: 'മലയാളം വിവരണം',
    observedImpact: 'കണ്ടെത്തിയ സ്വാധീനം:',
    primaryDriver: 'പ്രധാന കാരണം:',
    prescriptiveResolution: 'നിർദ്ദേശിച്ച പരിഹാരം',
    executeAction: 'നടപടി സ്വീകരിക്കുക',

    driverBuyBox: 'ബൈ ബോക്സ് പ്രകടനം',
    driverSearch: 'തിരച്ചിൽ സാന്നിധ്യം',
    driverInventory: 'ഇൻവെന്ററി സ്റ്റോക്ക് തലം',
    driverConversion: 'കൺവേർഷൻ നിരക്ക്',
    driverPricing: 'വില മത്സരക്ഷമത',
  },

  'French (Français)': {
    brandTitle: 'AuraSeller',
    marketplaceSubtitle: 'Intelligence Amazon 3P · Marché EAU (Amazon.ae)',
    tagline: 'Ce qui s’est passé · Pourquoi · Actions prioritaires',
    downloadExcel: 'Télécharger Excel',
    rootCauseDiagnosis: 'Diagnostic Cause Racine',
    sellerGenie: 'Seller Genie',
    live3dAi: 'IA 3D Direct',
    voiceDiagnostics: 'Conseiller Vocal',
    categoryLabel: 'Catégorie :',
    productLabel: 'Produit :',
    allProducts: 'Tous les produits (10 SKUs)',
    northStarLabel: 'Objectif Clé :',
    northStarValue: 'Volume d’affaires (GMV) par catégorie',
    timeWeekly: 'Hebdomadaire',
    timeMonthly: 'Mensuel',
    time90days: '90 derniers jours',

    tabAll: 'Tous les Modules',
    tabSales: 'Ventes & North Star',
    tabBuyBox: 'Boîte d’achat (Buy Box)',
    tabConversion: 'Entonnoir de Conversion',
    tabPricing: 'Prix & Concurrence',
    tabSearch: 'Visibilité Recherche',
    tabInventory: 'Stocks & Couverture (DOC)',

    sellerHealthTitle: 'Santé Financière Vendeur',
    weightedIndexPill: 'Indice Pondéré (5 Piliers × 20%)',
    sellerHealthSubtitle: 'Synthèse des performances Amazon Seller Central et des algorithmes',
    diagnoseWhy: 'Diagnostiquer Pourquoi',
    statusHealthy: 'Sain',
    statusActionNeeded: 'Action Requise',
    statusCritical: 'Critique',
    whyScoreButton: 'Pourquoi 78 pts ? Détail du calcul',
    totalMarketplaceRev: 'Revenu Total Marketplace',
    vsPrevPeriod: 'vs période précédente',
    revAtRisk: 'Revenu à Risque',
    issuesNeedAttention: 'problèmes à traiter',
    primaryConcernPrefix: 'Principal :',
    whatsDrivingChange: 'Qu’est-ce qui explique ce changement ?',
    hoverToInspect: 'Survoler pour inspecter',
    clickDriverToJump: 'Cliquer pour accéder au module ↓',
    primaryLoss: 'Perte Principale',

    doubleClickRevenueHint: '💡 Double-cliquez pour afficher Commandes × Prix et l’explication de la baisse de 12%',
    revenueDecompTitle: 'Décomposition du Revenu : Commandes × Prix',
    revenueFormula: 'Revenu Total = Nombre de Commandes × Prix Moyen (ASP)',
    why12DropTitle: 'Pourquoi cette baisse de 12% est-elle survenue ?',

    executiveSummary: 'Résumé Exécutif',
    diagnosticBrief: 'Note Diagnostique',
    whatHappened: '1. Que s’est-il passé ?',
    whyRootCause: '2. Pourquoi (Cause Racine) ?',
    nextBestAction: '3. Meilleure Action Suivante',
    plainSellerWordsTitle: 'Explication Simplifiée',
    plainSellerWordsBadge: 'Français Simple',
    observedImpact: 'Impact Observé :',
    primaryDriver: 'Facteur Principal :',
    prescriptiveResolution: 'Résolution prescrite',
    executeAction: 'Exécuter l’Action',

    driverBuyBox: 'Performance Buy Box',
    driverSearch: 'Visibilité dans la recherche',
    driverInventory: 'Niveau des stocks (DOC)',
    driverConversion: 'Taux de conversion',
    driverPricing: 'Compétitivité des prix',
  },

  'Spanish (Español)': {
    brandTitle: 'AuraSeller',
    marketplaceSubtitle: 'Inteligencia Amazon 3P · Mercado EAU (Amazon.ae)',
    tagline: 'Qué ocurrió · Por qué ocurrió · Qué requiere atención',
    downloadExcel: 'Descargar Excel',
    rootCauseDiagnosis: 'Diagnóstico Causa Raíz',
    sellerGenie: 'Seller Genie',
    live3dAi: 'IA 3D en Vivo',
    voiceDiagnostics: 'Diagnóstico por Voz',
    categoryLabel: 'Categoría:',
    productLabel: 'Producto:',
    allProducts: 'Todos los productos (10 SKUs)',
    northStarLabel: 'Métrica Clave:',
    northStarValue: 'GMV por producto y categoría',
    timeWeekly: 'Semanal',
    timeMonthly: 'Mensual',
    time90days: 'Últimos 90 días',

    tabAll: 'Todos los Módulos',
    tabSales: 'Ventas y North Star',
    tabBuyBox: 'Buy Box (Caja de Compra)',
    tabConversion: 'Embudo de Conversión',
    tabPricing: 'Precios y Competencia',
    tabSearch: 'Visibilidad de Búsqueda',
    tabInventory: 'Inventario y Días (DOC)',

    sellerHealthTitle: 'Salud de Ingresos del Vendedor',
    weightedIndexPill: 'Índice Ponderado (5 Pilares × 20%)',
    sellerHealthSubtitle: 'Sintetizado de Amazon Seller Central y algoritmos competitivos',
    diagnoseWhy: 'Diagnosticar Por Qué',
    statusHealthy: 'Saludable',
    statusActionNeeded: 'Acción Requerida',
    statusCritical: 'Crítico',
    whyScoreButton: '¿Por qué 78 pts? Desglose del cálculo',
    totalMarketplaceRev: 'Ingresos Totales Marketplace',
    vsPrevPeriod: 'vs periodo anterior',
    revAtRisk: 'Ingresos en Riesgo',
    issuesNeedAttention: 'problemas requieren atención',
    primaryConcernPrefix: 'Principal:',
    whatsDrivingChange: '¿Qué está impulsando el cambio?',
    hoverToInspect: 'Pase el ratón para inspeccionar',
    clickDriverToJump: 'Haga clic para ir al módulo ↓',
    primaryLoss: 'Pérdida Principal',

    doubleClickRevenueHint: '💡 Doble clic para ver Pedidos × Precio y la causa de la caída del 12%',
    revenueDecompTitle: 'Descomposición de Ingresos: Pedidos × Precio',
    revenueFormula: 'Ingresos Totales = Total de Pedidos × Precio Promedio de Venta (ASP)',
    why12DropTitle: '¿Por qué ocurrió la caída del 12%?',

    executiveSummary: 'Resumen Ejecutivo',
    diagnosticBrief: 'Informe Diagnóstico',
    whatHappened: '1. ¿Qué ocurrió?',
    whyRootCause: '2. ¿Por qué ocurrió (Causa Raíz)?',
    nextBestAction: '3. Próxima Mejor Acción',
    plainSellerWordsTitle: 'Explicación Simplificada',
    plainSellerWordsBadge: 'Español Sencillo',
    observedImpact: 'Impacto Observado:',
    primaryDriver: 'Impulsor Principal:',
    prescriptiveResolution: 'Resolución prescrita',
    executeAction: 'Ejecutar Acción',

    driverBuyBox: 'Rendimiento de Buy Box',
    driverSearch: 'Visibilidad de Búsqueda',
    driverInventory: 'Nivel de Inventario Saludable',
    driverConversion: 'Tasa de Conversión',
    driverPricing: 'Precios Competitivos',
  },

  'Arabic (العربية)': {
    brandTitle: 'أورا سيلر (AuraSeller)',
    marketplaceSubtitle: 'ذكاء بائعي أمازون · سوق الإمارات (Amazon.ae)',
    tagline: 'ماذا حدث · لماذا حدث · الإجراءات المطلوبة',
    downloadExcel: 'تحميل إكسل',
    rootCauseDiagnosis: 'تشخيص السبب الجذري',
    sellerGenie: 'جني البائع',
    live3dAi: 'ذكاء اصطناعي 3D مباشر',
    voiceDiagnostics: 'مستشار صوتي',
    categoryLabel: 'الفئة:',
    productLabel: 'المنتج:',
    allProducts: 'جميع المنتجات (10 منتجات)',
    northStarLabel: 'الهدف الرئيسي:',
    northStarValue: 'إجمالي قيمة المبيعات (GMV) حسب الفئة',
    timeWeekly: 'أسبوعي',
    timeMonthly: 'شهري',
    time90days: 'آخر 90 يوماً',

    tabAll: 'جميع الأقسام',
    tabSales: 'المبيعات والإيرادات',
    tabBuyBox: 'صندوق الشراء (Buy Box)',
    tabConversion: 'مسار التحويل (Conversion)',
    tabPricing: 'التسعير التنافسي',
    tabSearch: 'ظهور نتائج البحث',
    tabInventory: 'المخزون وأيام التغطية (DOC)',

    sellerHealthTitle: 'صحة إيرادات البائع',
    weightedIndexPill: 'مؤشر مرجح (5 ركائز × 20%)',
    sellerHealthSubtitle: 'مستخلص من أداء أمازون سيلر سنترال وخوارزميات التنافس',
    diagnoseWhy: 'تشخيص الأسباب',
    statusHealthy: 'جيد ومستقر',
    statusActionNeeded: 'مطلوب اتخاذ إجراء',
    statusCritical: 'حرج جداً',
    whyScoreButton: 'لماذا 78 نقطة؟ شرح المعادلة',
    totalMarketplaceRev: 'إجمالي إيرادات السوق',
    vsPrevPeriod: 'مقارنة بالفترة السابقة',
    revAtRisk: 'الإيرادات المعرضة للخطر',
    issuesNeedAttention: 'مشكلات بحاجة لمعالجة',
    primaryConcernPrefix: 'المشكلة الأساسية:',
    whatsDrivingChange: 'ما الذي يسبب هذا التغيير؟',
    hoverToInspect: 'مرر المؤشر للاطلاع على التفاصيل',
    clickDriverToJump: 'انقر للانتقال مباشرة إلى القسم ↓',
    primaryLoss: 'الخسارة الأساسية',

    doubleClickRevenueHint: '💡 انقر نقراً مزدوجاً لمشاهدة معادلة الطلبات × السعر وأسباب انخفاض 12%',
    revenueDecompTitle: 'تحليل الإيرادات: عدد الطلبات × متوسط السعر',
    revenueFormula: 'إجمالي الإيرادات = إجمالي الطلبات × متوسط سعر البيع (ASP)',
    why12DropTitle: 'لماذا حدث انخفاض بنسبة 12% في الإيرادات؟',

    executiveSummary: 'الملخص التنفيذي',
    diagnosticBrief: 'تقرير التشخيص',
    whatHappened: '1. ماذا حدث؟',
    whyRootCause: '2. لماذا حدث (السبب الجذري)؟',
    nextBestAction: '3. أفضل إجراء فوري قادم',
    plainSellerWordsTitle: 'شرح مبسط (Simplified Explanation)',
    plainSellerWordsBadge: 'شرح بالعربية',
    observedImpact: 'الأثر الملحوظ:',
    primaryDriver: 'المحرك الأساسي:',
    prescriptiveResolution: 'الحل الموصى به',
    executeAction: 'تنفيذ الإجراء فوراً',

    driverBuyBox: 'أداء صندوق الشراء (Buy Box)',
    driverSearch: 'ظهور المنتج في البحث',
    driverInventory: 'مستوى سلامة المخزون',
    driverConversion: 'معدل إتمام الشراء',
    driverPricing: 'التسعير التنافسي',
  },
};
