import React, { useState } from 'react';
import { 
  CATEGORIES_DATA,
  CATEGORIES_DATA_BY_PERIOD, 
  INITIAL_SELLER_HEALTH, 
  PRODUCTS_DATA,
  PRODUCTS_DATA_BY_PERIOD
} from './data/mockData';
import { 
  Currency, 
  ProductItem, 
  SupportedLanguage, 
  TimePeriod 
} from './types/seller';
import { Header } from './components/Header';
import { SellerHealthScoreCard } from './components/SellerHealthScoreCard';
import { RootCauseDiagnosisModal } from './components/RootCauseDiagnosisModal';
import { ConversionFunnelModule } from './components/ConversionFunnelModule';
import { BuyBoxModule } from './components/BuyBoxModule';
import { CompetitivePricingModule } from './components/CompetitivePricingModule';
import { SearchVisibilityModule } from './components/SearchVisibilityModule';
import { InventoryStockModule } from './components/InventoryStockModule';
import { SalesPerformanceModule } from './components/SalesPerformanceModule';
import { AiAdvisorCharacter } from './components/AiAdvisorCharacter';
import { QuickActionModal } from './components/QuickActionModal';
import { SectionSummaryCard } from './components/SectionSummaryCard';
import { formatCurrency, formatPercent } from './utils/formatters';
import { exportToExcel } from './utils/excelExport';
import { TRANSLATIONS } from './utils/translations';
import { 
  Zap, 
  Layers, 
  ShieldCheck, 
  Tag, 
  Search, 
  Package, 
  TrendingUp,
  AlertCircle,
  FileSpreadsheet
} from 'lucide-react';

export default function App() {
  // Global dashboard state
  const [timePeriod, setTimePeriod] = useState<TimePeriod>('weekly');
  const [currency, setCurrency] = useState<Currency>('AED');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedProductId, setSelectedProductId] = useState<string>('prod-sony-xm5');
  const [activeTab, setActiveTab] = useState<string>('all');
  const [highlightedModule, setHighlightedModule] = useState<string | null>(null);

  // Aha Feature AI Advisor state & Native Language Selector
  const [isAiAdvisorEnabled, setIsAiAdvisorEnabled] = useState<boolean>(true);
  const [aiLanguage, setAiLanguage] = useState<SupportedLanguage>('English');

  // Active translations dictionary
  const t = TRANSLATIONS[aiLanguage] || TRANSLATIONS.English;

  // Modals state
  const [isRootCauseModalOpen, setIsRootCauseModalOpen] = useState<boolean>(false);
  const [executedAction, setExecutedAction] = useState<{ title: string; type: string } | null>(null);

  // Active dataset keyed by selected Time Period (weekly / monthly / 90days)
  const sellerHealth = INITIAL_SELLER_HEALTH[timePeriod];
  const products = PRODUCTS_DATA_BY_PERIOD[timePeriod] || PRODUCTS_DATA;
  const categories = CATEGORIES_DATA_BY_PERIOD[timePeriod] || CATEGORIES_DATA;
  const activeProduct = products.find((p) => p.id === selectedProductId) || products[0];

  const handleExecuteAction = (title: string, type: string) => {
    setExecutedAction({ title, type });
  };

  const handleDownloadExcel = () => {
    exportToExcel({
      timePeriod,
      currency,
      products,
      categories,
      sellerHealth,
    });
  };

  // Requirement 1: Link the drivers to the sections on All modules on clicking
  const handleNavigateToModule = (mod: string) => {
    if (activeTab === 'all') {
      const el = document.getElementById(mod);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        setHighlightedModule(mod);
        setTimeout(() => setHighlightedModule(null), 2500);
      }
    } else {
      setActiveTab(mod);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const navTabs = [
    { id: 'all', label: t.tabAll },
    { id: 'sales', label: t.tabSales, icon: Layers },
    { id: 'buybox', label: t.tabBuyBox, icon: ShieldCheck },
    { id: 'conversion', label: t.tabConversion, icon: TrendingUp },
    { id: 'pricing', label: t.tabPricing, icon: Tag },
    { id: 'search', label: t.tabSearch, icon: Search },
    { id: 'inventory', label: t.tabInventory, icon: Package },
  ];

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors selection:bg-amber-500 selection:text-slate-950 pb-24">
      {/* Header */}
      <Header
        categories={categories}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        products={products}
        selectedProductId={selectedProductId}
        onSelectProduct={setSelectedProductId}
        timePeriod={timePeriod}
        onSelectTimePeriod={setTimePeriod}
        currency={currency}
        onSelectCurrency={setCurrency}
        isAiAdvisorEnabled={isAiAdvisorEnabled}
        onToggleAiAdvisor={() => setIsAiAdvisorEnabled(!isAiAdvisorEnabled)}
        aiLanguage={aiLanguage}
        onSelectLanguage={setAiLanguage}
        onOpenRootCauseModal={() => setIsRootCauseModalOpen(true)}
        onDownloadExcel={handleDownloadExcel}
        translations={t}
      />

      {/* Main Container with Two-Column Split (Fixed Left: Seller Revenue Health, Scrollable Right: Modules) */}
      <main className="max-w-[1580px] mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <div className="flex flex-col lg:flex-row gap-6 items-start">
          
          {/* Fixed / Sticky Left Sidebar: Seller Revenue Health */}
          <aside className="w-full lg:w-[380px] xl:w-[420px] shrink-0 lg:sticky lg:top-20 lg:self-start lg:max-h-[calc(100vh-5.5rem)] lg:overflow-y-auto pr-1 pb-4 scrollbar-thin">
            <section id="seller-health">
              <SellerHealthScoreCard
                healthData={sellerHealth}
                timePeriod={timePeriod}
                currency={currency}
                onOpenRootCauseModal={() => setIsRootCauseModalOpen(true)}
                onNavigateToModule={handleNavigateToModule}
                translations={t}
                isSidebarMode={true}
              />
            </section>
          </aside>

          {/* Scrollable Right Content Area: Nav tabs + All module sections */}
          <div className="flex-1 min-w-0 space-y-6">
            
            {/* Module Navigation Tabs (Sticky at top of scrollable area) */}
            <div className="sticky top-16 z-20 bg-slate-100/90 dark:bg-slate-950/90 backdrop-blur-md py-2 -mt-2">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {navTabs.map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;

                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                        isActive
                          ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950 shadow-sm'
                          : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      {Icon && <Icon className="w-3.5 h-3.5" />}
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Module Sections filtered or all */}
            {(activeTab === 'all' || activeTab === 'sales') && (
              <section id="sales" className={`transition-all duration-500 rounded-2xl ${highlightedModule === 'sales' ? 'ring-4 ring-amber-500 shadow-xl' : ''}`}>
                <SalesPerformanceModule
                  products={products}
                  selectedCategory={selectedCategory}
                  currency={currency}
                  timePeriod={timePeriod}
                  onSelectProduct={setSelectedProductId}
                  onExecuteAction={handleExecuteAction}
                />
              </section>
            )}

            {(activeTab === 'all' || activeTab === 'buybox') && (
              <section id="buybox" className={`transition-all duration-500 rounded-2xl ${highlightedModule === 'buybox' ? 'ring-4 ring-amber-500 shadow-xl' : ''}`}>
                <BuyBoxModule
                  products={products}
                  selectedProductId={selectedProductId}
                  currency={currency}
                  timePeriod={timePeriod}
                  onSelectProduct={setSelectedProductId}
                  onExecuteAction={handleExecuteAction}
                />
              </section>
            )}

            {(activeTab === 'all' || activeTab === 'conversion') && (
              <section id="conversion" className={`transition-all duration-500 rounded-2xl ${highlightedModule === 'conversion' ? 'ring-4 ring-amber-500 shadow-xl' : ''}`}>
                <ConversionFunnelModule
                  products={products}
                  selectedProductId={selectedProductId}
                  currency={currency}
                  timePeriod={timePeriod}
                  onSelectProduct={setSelectedProductId}
                  onExecuteAction={handleExecuteAction}
                />
              </section>
            )}

            {(activeTab === 'all' || activeTab === 'pricing') && (
              <section id="pricing" className={`transition-all duration-500 rounded-2xl ${highlightedModule === 'pricing' ? 'ring-4 ring-amber-500 shadow-xl' : ''}`}>
                <CompetitivePricingModule
                  products={products}
                  selectedProductId={selectedProductId}
                  currency={currency}
                  timePeriod={timePeriod}
                  onSelectProduct={setSelectedProductId}
                  onExecuteAction={handleExecuteAction}
                />
              </section>
            )}

            {(activeTab === 'all' || activeTab === 'search') && (
              <section id="search" className={`transition-all duration-500 rounded-2xl ${highlightedModule === 'search' ? 'ring-4 ring-amber-500 shadow-xl' : ''}`}>
                <SearchVisibilityModule
                  products={products}
                  selectedProductId={selectedProductId}
                  currency={currency}
                  timePeriod={timePeriod}
                  onSelectProduct={setSelectedProductId}
                  onExecuteAction={handleExecuteAction}
                />
              </section>
            )}

            {(activeTab === 'all' || activeTab === 'inventory') && (
              <section id="inventory" className={`transition-all duration-500 rounded-2xl ${highlightedModule === 'inventory' ? 'ring-4 ring-amber-500 shadow-xl' : ''}`}>
                <InventoryStockModule
                  products={products}
                  selectedCategory={selectedCategory}
                  currency={currency}
                  timePeriod={timePeriod}
                  onExecuteAction={handleExecuteAction}
                />
              </section>
            )}

            {/* Global All Modules Comprehensive Summary (Rendered at end of All Modules view) */}
            {activeTab === 'all' && (
              <section id="all-modules-summary" className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 gap-2">
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded-md bg-amber-500/10 text-amber-500 font-black text-xs">ALL</span>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      All Modules — Integrated Portfolio Health Review
                    </h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleDownloadExcel}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95"
                      title="Download complete 10-product 5-category Excel spreadsheet"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      <span>Download Excel (.xlsx)</span>
                    </button>
                    <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                      Cross-Functional Diagnostic
                    </span>
                  </div>
                </div>

                <SectionSummaryCard
                  sectionName="All Modules"
                  whatHappened={{
                    headline: `Portfolio GMV pacing at ${formatCurrency(sellerHealth.totalRevenue, currency)} (${formatPercent(sellerHealth.revenueDeltaPercent)} change) with cross-module margin compression`,
                    description: `Across all 6 modules, our catalogue experienced 18 peak hours of Buy Box loss, unit session conversion fell to 11.2%, organic search share decayed by 22.8%, and flagship inventory is constrained at 8.2 Days of Cover.`,
                    keyMetric: "-12.4% vs Target GMV",
                    trend: "down",
                    impact: `${formatCurrency(34800, currency)} Net Portfolio Leakage`,
                  }}
                  why={{
                    headline: "Compounding chain reaction: Automated rival price cuts cascaded into Buy Box loss, A9 rank decay, and stockout pressure",
                    description: "3P competitors initiated aggressive repricing below MAP thresholds. The resulting Buy Box loss triggered a lower conversion velocity, signaling down-ranking to Amazon A9 algorithms, while supplier lead-time delays created an imminent stockout bottleneck.",
                    category: "Cross-Module Algorithmic Chain Reaction",
                    impact: "Primary Driver: Buy Box suppression cascaded into organic search rank and conversion decay",
                  }}
                  nextBestAction={{
                    headline: "Execute Full 3-Point Cross-Functional Stabilization Plan",
                    description: "1) Re-anchor Buy Box with automated repricer at AED 1,075. 2) Deploy instant 5% digital voucher badge to recover conversion. 3) Dispatch 350 emergency air-freight units to FBA DXB to avoid delisting.",
                    actionTitle: "Execute Portfolio Plan",
                    actionType: "portfolio_recovery",
                    estimatedLift: `+${formatCurrency(28600, currency)} Recoverable GMV`,
                    onExecute: () => handleExecuteAction("Executed Integrated Cross-Module Stabilization Plan", "portfolio_recovery"),
                  }}
                  plainSellerWords={{
                    summary: "Across your entire 10-product store, you made 12% less money this week because competitor sellers cut their prices by a few dirhams and stole your 'Buy Now' button for 18 peak shopping hours. Because fewer people bought from your page, Amazon's search algorithm pushed your items down the search results. Meanwhile, your warehouse is down to 8 days of stock on your top-selling headphones.",
                    actionTip: "Match their prices right now to get your Buy Box back, add a 5% off coupon to get sales flowing, and send more inventory by air courier to Amazon's Dubai warehouse before you sell out next week.",
                  }}
                  translations={t}
                  className="mt-2 pt-2 border-t-0"
                />
              </section>
            )}

          </div>
        </div>
      </main>

      {/* Root Cause Diagnosis Modal */}
      <RootCauseDiagnosisModal
        isOpen={isRootCauseModalOpen}
        onClose={() => setIsRootCauseModalOpen(false)}
        products={products}
        currency={currency}
        initialProductId={selectedProductId}
        onExecuteAction={handleExecuteAction}
      />

      {/* Action Execution Confirmation Modal */}
      {executedAction && (
        <QuickActionModal
          isOpen={Boolean(executedAction)}
          onClose={() => setExecutedAction(null)}
          actionTitle={executedAction.title}
          actionType={executedAction.type}
        />
      )}

      {/* Aha Feature: Multilingual AI Seller Advisor */}
      <AiAdvisorCharacter
        isEnabled={isAiAdvisorEnabled}
        onToggle={() => setIsAiAdvisorEnabled(!isAiAdvisorEnabled)}
        language={aiLanguage}
        onSelectLanguage={setAiLanguage}
        sellerHealth={sellerHealth}
        activeProduct={activeProduct}
        currency={currency}
        timePeriod={timePeriod}
        onExecuteAction={handleExecuteAction}
      />
    </div>
  );
}
