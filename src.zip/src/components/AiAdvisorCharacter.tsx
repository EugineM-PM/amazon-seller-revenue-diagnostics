import React, { useState, useEffect, useRef } from 'react';
import { 
  Volume2, 
  VolumeX, 
  Globe2, 
  RotateCcw, 
  X, 
  ChevronDown, 
  ChevronUp, 
  Minimize2,
  Maximize2,
  Play, 
  Pause, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  Package, 
  TrendingUp, 
  Sparkles 
} from 'lucide-react';
import { Currency, ProductItem, SellerHealthData, SupportedLanguage, TimePeriod } from '../types/seller';
import { formatCurrency, formatPercent } from '../utils/formatters';
import { Live3DAvatar } from './Live3DAvatar';

interface AiAdvisorCharacterProps {
  isEnabled: boolean;
  onToggle: () => void;
  language: SupportedLanguage;
  onSelectLanguage: (lang: SupportedLanguage) => void;
  sellerHealth: SellerHealthData;
  activeProduct: ProductItem;
  currency: Currency;
  timePeriod: TimePeriod;
  onExecuteAction: (title: string, type: string) => void;
}

export type NarrationTopic = 'overview' | 'buybox' | 'inventory' | 'actions';

export const AiAdvisorCharacter: React.FC<AiAdvisorCharacterProps> = ({
  isEnabled,
  onToggle,
  language,
  onSelectLanguage,
  sellerHealth,
  activeProduct,
  currency,
  timePeriod,
  onExecuteAction,
}) => {
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);
  const [isExpanded, setIsExpanded] = useState<boolean>(true);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [activeTopic, setActiveTopic] = useState<NarrationTopic>('overview');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [explanation, setExplanation] = useState<string>('');
  const [speechSupported, setSpeechSupported] = useState<boolean>(true);

  const speechUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const languages: SupportedLanguage[] = [
    'English',
    'Telugu (తెలుగు)',
    'Tamil (தமிழ்)',
    'Hindi (हिंदी)',
    'Malayalam (മലയാളം)',
    'French (Français)',
    'Spanish (Español)',
    'Arabic (العربية)',
  ];

  // Map language to BCP 47 voice code
  const getLanguageLocale = (lang: SupportedLanguage): string => {
    if (lang.includes('Telugu')) return 'te-IN';
    if (lang.includes('Tamil')) return 'ta-IN';
    if (lang.includes('Hindi')) return 'hi-IN';
    if (lang.includes('Malayalam')) return 'ml-IN';
    if (lang.includes('French')) return 'fr-FR';
    if (lang.includes('Spanish')) return 'es-ES';
    if (lang.includes('Arabic')) return 'ar-AE';
    return 'en-US';
  };

  // Concise prompt generator based on topic
  const getTopicPrompt = (topic: NarrationTopic): string => {
    switch (topic) {
      case 'overview':
        return `Explain the overall health score (${sellerHealth.overallScore}/100, dropping by ${Math.abs(sellerHealth.scoreDelta)} pts) and revenue (${formatCurrency(sellerHealth.totalRevenue, currency)}) in 3 quick sentences.`;
      case 'buybox':
        return `Explain why ${activeProduct.name} lost Buy Box (fell from ${activeProduct.prevBuyBoxPct}% to ${activeProduct.buyBoxPct}% due to competitor price ${formatCurrency(activeProduct.lowestCompetitorPrice, currency)}) in 3 quick sentences.`;
      case 'inventory':
        return `Explain inventory stock levels and days of cover (${activeProduct.daysOfCover} DOC) in 3 quick sentences.`;
      case 'actions':
        return `Give the 3 fastest actions to recover revenue at risk (${formatCurrency(sellerHealth.revenueAtRisk, currency)}) today on Amazon Seller Central.`;
    }
  };

  // Fetch explanation from server
  const fetchAdvice = async (topic: NarrationTopic = activeTopic, autoSpeak: boolean = true) => {
    setIsLoading(true);
    stopSpeaking();

    try {
      const sellerContext = {
        healthScore: sellerHealth.overallScore,
        scoreChange: `${sellerHealth.scoreDelta > 0 ? '+' : ''}${sellerHealth.scoreDelta} pts`,
        revenue: formatCurrency(sellerHealth.totalRevenue, currency),
        revenueChange: formatPercent(sellerHealth.revenueDeltaPercent),
        revenueAtRisk: formatCurrency(sellerHealth.revenueAtRisk, currency),
        primaryIssue: sellerHealth.primaryConcern,
        buyBoxChange: `${sellerHealth.drivers.buyBox.deltaPts} pts`,
        searchChange: `${sellerHealth.drivers.searchVisibility.deltaPts} pts`,
        inventoryChange: `+${sellerHealth.drivers.inventory.deltaPts} pts`,
        convChange: `+${sellerHealth.drivers.conversion.deltaPts} pts`,
        priceChange: `+${sellerHealth.drivers.pricing.deltaPts} pt`,
      };

      const productContext = {
        name: activeProduct.name,
        revenue: formatCurrency(activeProduct.revenue, currency),
        revenueChange: formatPercent(activeProduct.revenueChangePct),
        buyBoxStatus: `${activeProduct.prevBuyBoxPct}% → ${activeProduct.buyBoxPct}% (${activeProduct.buyBoxPPChange} PP)`,
        competitorPrice: `Competitor undercut to ${formatCurrency(activeProduct.lowestCompetitorPrice, currency)} (vs ${formatCurrency(activeProduct.currentPrice, currency)})`,
        searchVisibility: `Rank #${activeProduct.overallSearchRank} (${activeProduct.searchTerms[0]?.term})`,
        conversionRate: `${activeProduct.currentConversionPct}% (${activeProduct.purchases} orders from ${activeProduct.productViews} views)`,
        inventoryStatus: `${activeProduct.daysOfCover} Days of Cover (${activeProduct.currentStockUnits} units in stock)`,
        diagnosis: activeProduct.diagnosisSummary.verdict,
      };

      const response = await fetch('/api/advisor/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          language,
          sellerContext,
          productContext,
          question: getTopicPrompt(topic),
        }),
      });

      const data = await response.json();
      if (data.explanation) {
        setExplanation(data.explanation);
        if (autoSpeak) {
          // Play speech with freshly loaded text
          speakCleanText(data.explanation);
        }
      }
    } catch (err) {
      console.error('Failed to load AI advice:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Switch narration topic and speak
  const handleSelectTopic = (topic: NarrationTopic) => {
    setActiveTopic(topic);
    fetchAdvice(topic, true);
  };

  // Reload advice whenever language, active product, or time period changes
  useEffect(() => {
    if (isEnabled) {
      fetchAdvice(activeTopic, false);
    }
    return () => {
      stopSpeaking();
    };
  }, [isEnabled, language, activeProduct.id, timePeriod]);

  // Voice narration helper using Web Speech Synthesis API
  const speakCleanText = (text: string) => {
    if (!('speechSynthesis' in window)) {
      setSpeechSupported(false);
      return;
    }

    window.speechSynthesis.cancel();

    // Clean markdown characters for crisp audio
    const cleanText = text
      .replace(/[*#_~`]/g, '')
      .replace(/•/g, ', ')
      .replace(/AED/g, 'AED ')
      .replace(/↓/g, 'down ')
      .replace(/↑/g, 'up ');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = getLanguageLocale(language);
    utterance.rate = 1.05; // Quick and concise tempo
    utterance.pitch = 1.08; // Friendly Seller Genie voice tone

    const voices = window.speechSynthesis.getVoices();
    const matchedVoice = voices.find((v) => v.lang.startsWith(utterance.lang.slice(0, 2)));
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    speechUtteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  const toggleSpeak = () => {
    if (isSpeaking) {
      stopSpeaking();
    } else if (explanation) {
      speakCleanText(explanation);
    } else {
      fetchAdvice(activeTopic, true);
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  if (!isEnabled) {
    return (
      <div className="fixed bottom-4 right-4 z-40">
        <button
          onClick={onToggle}
          className="flex items-center gap-2 pl-1.5 pr-3 py-1.5 rounded-full bg-slate-900 text-white font-bold text-[11px] shadow-xl border border-amber-500/40 hover:border-amber-400 hover:scale-105 transition-all cursor-pointer group"
          title="Click to activate Seller Genie"
        >
          <div className="w-6 h-6 rounded-full overflow-hidden bg-slate-800 border border-amber-400 flex items-center justify-center">
            <Live3DAvatar isSpeaking={false} size={28} className="scale-75" />
          </div>
          <div className="flex flex-col text-left leading-none">
            <span className="font-bold text-white flex items-center gap-1">
              Seller Genie
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            </span>
            <span className="text-[9px] text-amber-300 font-medium">3D Advisor</span>
          </div>
        </button>
      </div>
    );
  }

  // Collapsed View: compact floating bar docked at bottom right (half size)
  if (isCollapsed) {
    return (
      <aside 
        aria-label="Seller Genie - Live 3D AI Advisor (Collapsed)" 
        className="fixed bottom-4 right-4 z-40 flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-950/95 text-white border border-amber-500/40 shadow-xl backdrop-blur-md transition-all duration-300 hover:border-amber-400 max-w-[220px]"
      >
        <button
          onClick={() => setIsCollapsed(false)}
          className="flex items-center gap-2 cursor-pointer text-left group"
          title="Click to expand Seller Genie 3D Advisor"
        >
          <div className="relative w-7 h-7 rounded-lg overflow-hidden bg-slate-900 border border-amber-400/80 flex items-center justify-center shrink-0 shadow-inner group-hover:scale-105 transition-transform">
            <Live3DAvatar isSpeaking={isSpeaking} size={28} className="scale-75" />
            {isSpeaking && (
              <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            )}
          </div>
          <div className="flex flex-col leading-none">
            <div className="flex items-center gap-1">
              <span className="text-[11px] font-bold text-white group-hover:text-amber-400 transition-colors">
                Seller Genie
              </span>
            </div>
            <span className="text-[9px] text-slate-400 mt-0.5">
              {isSpeaking ? (
                <span className="text-emerald-400 font-medium">Speaking...</span>
              ) : (
                'Expand'
              )}
            </span>
          </div>
        </button>

        <div className="h-4 w-[1px] bg-slate-800 mx-0.5" />

        <div className="flex items-center gap-0.5">
          {/* Quick Voice Play / Pause */}
          <button
            onClick={toggleSpeak}
            className={`p-1 rounded-md transition-colors cursor-pointer ${
              isSpeaking
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
            title={isSpeaking ? 'Pause Speaking' : `Speak in ${language}`}
          >
            {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>

          {/* Expand Button */}
          <button
            onClick={() => setIsCollapsed(false)}
            className="p-1 rounded-md text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Expand 3D Advisor window"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>

          {/* Turn Off / Hide */}
          <button
            onClick={onToggle}
            className="p-1 rounded-md text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close Seller Genie"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </aside>
    );
  }

  return (
    <aside aria-label="Seller Genie - Live 3D AI Advisor" className="fixed bottom-4 right-4 z-40 w-[calc(100vw-2rem)] sm:w-72 max-w-[280px] max-h-[385px] flex flex-col shadow-2xl rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden transition-all duration-300">
      
      {/* 3D Character Stage & Header */}
      <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 p-2.5 text-white border-b border-slate-800 shrink-0">
        
        {/* Top Control Bar */}
        <div className="flex items-center justify-between pb-1.5 border-b border-slate-800/80 mb-2">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[11px] font-black tracking-wide text-white">SELLER GENIE</span>
            <span className="text-[8px] text-amber-400 font-semibold bg-amber-950/70 border border-amber-800 px-1 py-0.2 rounded">
              3D AI
            </span>
          </div>

          <div className="flex items-center gap-0.5">
            {/* Quick voice mute / unmute */}
            <button
              onClick={toggleSpeak}
              className={`p-1 rounded transition-colors cursor-pointer ${
                isSpeaking
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
              title={isSpeaking ? 'Pause Speaking' : `Speak in ${language}`}
            >
              {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            </button>

            {/* Collapse window to compact dock */}
            <button
              onClick={() => setIsCollapsed(true)}
              className="p-1 rounded text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="Collapse Seller Genie window"
            >
              <Minimize2 className="w-3.5 h-3.5" />
            </button>

            {/* Minimize / Toggle report details */}
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1 rounded text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title={isExpanded ? 'Hide Details' : 'Show Details'}
            >
              {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
            </button>

            {/* Turn off */}
            <button
              onClick={onToggle}
              className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
              title="Close Seller Genie"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 3D Character Hero Box */}
        <div className="flex items-center gap-2.5">
          {/* Live Interactive 3D Canvas */}
          <div className="relative shrink-0 flex items-center justify-center bg-slate-900/90 rounded-xl border border-slate-700/80 shadow-inner p-1 group">
            <Live3DAvatar
              isSpeaking={isSpeaking}
              onClick={toggleSpeak}
              size={80}
              className="rounded-lg overflow-hidden"
            />
            {isSpeaking && (
              <div className="absolute top-1 right-1 px-1 py-0.2 rounded bg-emerald-500/90 text-slate-950 text-[7.5px] font-extrabold flex items-center gap-0.5 shadow-xs">
                <span className="w-1 h-1 rounded-full bg-slate-950 animate-ping" />
                LIVE
              </div>
            )}
          </div>

          {/* Quick Stats at a glance */}
          <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5 space-y-1">
            <div className="flex items-center justify-between leading-none">
              <span className="text-[10px] text-slate-400 font-medium">Health</span>
              <div className="flex items-center gap-1">
                <span className="text-xs font-black text-white">{sellerHealth.overallScore}/100</span>
                <span className="text-[9.5px] font-bold text-rose-400">
                  {sellerHealth.scoreDelta > 0 ? `+${sellerHealth.scoreDelta}` : sellerHealth.scoreDelta}
                </span>
              </div>
            </div>

            <div className="text-[9.5px] text-slate-300 truncate leading-tight">
              <strong className="text-amber-300">{sellerHealth.primaryConcern}</strong>
            </div>

            {/* Quick Action Audio Trigger */}
            <button
              onClick={toggleSpeak}
              className={`w-full py-1 px-2 rounded-lg font-bold text-[9.5px] flex items-center justify-center gap-1 transition-all cursor-pointer shadow-xs ${
                isSpeaking
                  ? 'bg-rose-600 hover:bg-rose-500 text-white'
                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
              }`}
            >
              {isSpeaking ? (
                <>
                  <Pause className="w-2.5 h-2.5 fill-current" />
                  <span>Pause Voice</span>
                </>
              ) : (
                <>
                  <Play className="w-2.5 h-2.5 fill-current" />
                  <span>Hear Advice</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>

      {/* Expanded Content: Scrollable concise report */}
      {isExpanded && (
        <div className="p-2.5 space-y-2 flex-1 min-h-0 overflow-y-auto">
          
          {/* Language Selector */}
          <div className="flex items-center justify-between gap-1 p-1.5 bg-slate-50 dark:bg-slate-800/60 rounded-lg border border-slate-200/80 dark:border-slate-800 text-[10px]">
            <span className="font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <Globe2 className="w-3 h-3 text-amber-500" />
              Language:
            </span>
            <select
              value={language}
              onChange={(e) => onSelectLanguage(e.target.value as SupportedLanguage)}
              className="bg-transparent text-[10px] font-bold text-amber-600 dark:text-amber-400 focus:outline-none cursor-pointer text-right max-w-[125px] truncate"
            >
              {languages.map((l) => (
                <option key={l} value={l} className="bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 font-medium">
                  {l}
                </option>
              ))}
            </select>
          </div>

          {/* Quick-Listen Topic Buttons - Horizontal chips */}
          <div className="flex items-center gap-1 overflow-x-auto pb-0.5 scrollbar-none">
            {[
              { id: 'overview', label: '📊 Health' },
              { id: 'buybox', label: '🛡️ Buy Box' },
              { id: 'inventory', label: '📦 Stock' },
              { id: 'actions', label: '⚡ Actions' },
            ].map(({ id, label }) => (
              <button
                key={id}
                onClick={() => handleSelectTopic(id as NarrationTopic)}
                className={`px-2 py-0.5 rounded-md text-[9.5px] font-semibold whitespace-nowrap transition-all cursor-pointer border ${
                  activeTopic === id
                    ? 'bg-amber-500 text-slate-950 border-amber-600 font-bold shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800/70 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Spoken Narration Transcript & Summary (Chat Box) */}
          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-850/90 border border-slate-200 dark:border-slate-800 text-[10.5px] leading-relaxed min-h-[110px] max-h-44 overflow-y-auto shadow-inner">
            {isLoading ? (
              <div className="flex items-center gap-2 py-3 text-slate-500">
                <div className="w-3.5 h-3.5 rounded-full border-2 border-amber-500 border-t-transparent animate-spin" />
                <span>Preparing live advice in {language}...</span>
              </div>
            ) : (
              <div className="space-y-1.5 whitespace-pre-line text-slate-800 dark:text-slate-200 font-normal">
                {explanation}
              </div>
            )}
          </div>

          {/* Quick Action Button */}
          <div className="pt-0.5">
            <button
              onClick={() => onExecuteAction(`Apply Automated Fix for ${activeProduct.name}`, 'reprice')}
              className="w-full py-1.5 px-2 rounded-lg bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-950 font-bold text-[10px] transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
            >
              <span>Apply Reclaim Fix</span>
              <span>→</span>
            </button>
          </div>

        </div>
      )}
    </aside>
  );
};


