import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface Live3DAvatarProps {
  isSpeaking: boolean;
  onClick?: () => void;
  className?: string;
  size?: number; // e.g. 64, 80, 100
}

/**
 * Procedural Live 3D Seller Genie Mascot in Three.js
 * 
 * Styled exactly like the iconic Doughboy reference image, dressed in a sharp rich royal blue business suit:
 * - FULL VISIBLE BODY: Head, tall pleated toque hat, torso, tailored blue suit,
 *   full trouser legs, grounded oxford shoes, and BOTH HANDS sculpted with distinct thumbs & fingers.
 * - EXPRESSIVE DUAL-HAND EXPLANATION: When speaking, the avatar uses BOTH hands in coordinated,
 *   communicative presentation gestures (palms open, alternating sweeps, dual emphasis pulses).
 * - When idle, seamlessly transitions to the signature Doughboy high right-hand wave and resting left hand.
 * - Authentic Doughboy features: button nose, chubby cheeks, wide crescent smile, sapphire blue eyes,
 *   and polished gold spectacles.
 */
export const Live3DAvatar: React.FC<Live3DAvatarProps> = ({
  isSpeaking,
  onClick,
  className = '',
  size = 80,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const isSpeakingRef = useRef<boolean>(isSpeaking);

  // Sync prop changes without triggering full canvas rebuilds
  useEffect(() => {
    isSpeakingRef.current = isSpeaking;
  }, [isSpeaking]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Dimensions
    const width = container.clientWidth || size;
    const height = container.clientHeight || size;

    // 1. Scene setup
    const scene = new THREE.Scene();

    // 2. Camera setup - framed to capture the ENTIRE Doughboy (both hands, legs, feet, and tall hat)
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 0.48, 4.9);
    camera.lookAt(0, 0.42, 0);

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 4. Studio Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.25);
    scene.add(ambientLight);

    // Warm key front light (brings out rich blue fabric, gold accents, and smooth dough skin)
    const keyLight = new THREE.DirectionalLight(0xfff8ee, 1.9);
    keyLight.position.set(2.4, 4.2, 3.2);
    scene.add(keyLight);

    // Cool fill light for blue suit shadows
    const fillLight = new THREE.DirectionalLight(0xa0c4ff, 1.15);
    fillLight.position.set(-3.0, 1.2, 2.2);
    scene.add(fillLight);

    // Crisp rim highlight for silhouette definition (rims hat, waving hand, and legs)
    const rimLight = new THREE.DirectionalLight(0xffffff, 1.55);
    rimLight.position.set(0, 5.0, -2.5);
    scene.add(rimLight);

    // Floor bounce light for shoes and lower legs
    const groundBounce = new THREE.DirectionalLight(0xfef2f2, 0.5);
    groundBounce.position.set(0, -3.0, 1.5);
    scene.add(groundBounce);

    // ==========================================
    // 5. Materials
    // ==========================================
    // Soft creamy marshmallow dough skin
    const doughMat = new THREE.MeshStandardMaterial({
      color: 0xfbf9f4,
      roughness: 0.36,
      metalness: 0.03,
    });

    // Crisp white hat & dress shirt fabric
    const whiteFabricMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.42,
      metalness: 0.02,
    });

    // Rich Royal Blue Business Suit fabric
    const richBlueSuitMat = new THREE.MeshStandardMaterial({
      color: 0x1d4ed8, // Vibrant rich royal blue
      roughness: 0.5,
      metalness: 0.14,
    });

    // Deep Navy Lapels & Welt Pocket
    const deepNavyMat = new THREE.MeshStandardMaterial({
      color: 0x1e3a8a,
      roughness: 0.44,
      metalness: 0.18,
    });

    // Power Crimson Silk Necktie
    const tieMat = new THREE.MeshStandardMaterial({
      color: 0xbe123c,
      roughness: 0.3,
      metalness: 0.22,
    });

    // Polished gold metallic buttons, tie bar, and pin
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.9,
      roughness: 0.16,
    });

    // Polished Oxford Shoes
    const shoeMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.22,
      metalness: 0.38,
    });

    // Iconic Doughboy Blue Eyes
    const eyeBlueMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      roughness: 0.15,
      metalness: 0.1,
    });

    const pupilMat = new THREE.MeshBasicMaterial({
      color: 0x03254c,
    });

    const eyeHighlightMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
    });

    // Cheerful mouth interior
    const mouthInteriorMat = new THREE.MeshStandardMaterial({
      color: 0x881337,
      roughness: 0.4,
    });

    const tongueMat = new THREE.MeshStandardMaterial({
      color: 0xf43f5e,
      roughness: 0.32,
    });

    // Subtle rosy cheeks
    const cheekMat = new THREE.MeshStandardMaterial({
      color: 0xffd2cb,
      roughness: 0.6,
      transparent: true,
      opacity: 0.45,
    });

    // Glasses Frame Material (polished metallic gold)
    const glassesFrameMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      metalness: 0.88,
      roughness: 0.18,
    });

    const glassesLensMat = new THREE.MeshPhysicalMaterial({
      color: 0xbfe0fe,
      transparent: true,
      opacity: 0.22,
      roughness: 0.05,
      metalness: 0.85,
      transmission: 0.7,
      ior: 1.5,
    });

    // Blue oval logo on hat band
    const logoBlueMat = new THREE.MeshStandardMaterial({
      color: 0x1d4ed8,
      roughness: 0.2,
      metalness: 0.1,
    });

    // Floor Contact Shadow Material
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x020617,
      transparent: true,
      opacity: 0.35,
    });

    // Telemetry data ring in background
    const telemetryMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.16,
      wireframe: true,
    });

    // ==========================================
    // 6. Character Hierarchy (Root Group)
    // ==========================================
    const characterGroup = new THREE.Group();
    characterGroup.position.y = -0.15;
    scene.add(characterGroup);

    // Ground Contact Shadow (makes legs and feet unmistakably grounded)
    const floorShadowGeo = new THREE.CircleGeometry(0.72, 32);
    const floorShadow = new THREE.Mesh(floorShadowGeo, shadowMat);
    floorShadow.rotation.x = -Math.PI / 2;
    floorShadow.position.set(0, -0.68, 0.05);
    characterGroup.add(floorShadow);

    // Subtle background telemetry rings
    const telemetryGroup = new THREE.Group();
    telemetryGroup.position.set(0, 0.65, -0.3);
    characterGroup.add(telemetryGroup);

    const ringGeo1 = new THREE.TorusGeometry(1.05, 0.008, 12, 40);
    const ringMesh1 = new THREE.Mesh(ringGeo1, telemetryMat);
    telemetryGroup.add(ringMesh1);

    const ringGeo2 = new THREE.TorusGeometry(0.88, 0.006, 12, 36);
    const ringMesh2 = new THREE.Mesh(ringGeo2, telemetryMat);
    ringMesh2.rotation.x = Math.PI / 3.2;
    telemetryGroup.add(ringMesh2);

    // ==========================================
    // Body Core (Chubby pear-shaped dough belly)
    // ==========================================
    const bodyGeo = new THREE.SphereGeometry(0.72, 32, 32);
    bodyGeo.scale(1.02, 1.12, 0.98);
    const bodyMesh = new THREE.Mesh(bodyGeo, doughMat);
    bodyMesh.position.y = 0.05;
    characterGroup.add(bodyMesh);

    // ==========================================
    // Tailored Rich Blue Suit Jacket
    // ==========================================
    const suitGroup = new THREE.Group();
    suitGroup.position.set(0, 0.05, 0);
    characterGroup.add(suitGroup);

    // 1. Blue Suit Jacket Main Body Shell
    const jacketShellGeo = new THREE.SphereGeometry(0.742, 32, 24, 0, Math.PI * 2, Math.PI * 0.22, Math.PI * 0.64);
    jacketShellGeo.scale(1.02, 1.11, 0.99);
    const jacketShell = new THREE.Mesh(jacketShellGeo, richBlueSuitMat);
    suitGroup.add(jacketShell);

    // 2. White Dress Shirt V-Chest Placket
    const shirtVGeo = new THREE.CylinderGeometry(0.25, 0.08, 0.52, 16);
    const shirtVMesh = new THREE.Mesh(shirtVGeo, whiteFabricMat);
    shirtVMesh.position.set(0, 0.28, 0.68);
    shirtVMesh.rotation.x = -0.15;
    suitGroup.add(shirtVMesh);

    // 3. Left Suit Lapel
    const leftLapelGeo = new THREE.BoxGeometry(0.13, 0.44, 0.035);
    const leftLapel = new THREE.Mesh(leftLapelGeo, deepNavyMat);
    leftLapel.position.set(-0.16, 0.24, 0.7);
    leftLapel.rotation.set(-0.16, 0.28, 0.34);
    suitGroup.add(leftLapel);

    // 4. Right Suit Lapel
    const rightLapelGeo = new THREE.BoxGeometry(0.13, 0.44, 0.035);
    const rightLapel = new THREE.Mesh(rightLapelGeo, deepNavyMat);
    rightLapel.position.set(0.16, 0.24, 0.7);
    rightLapel.rotation.set(-0.16, -0.28, -0.34);
    suitGroup.add(rightLapel);

    // 5. Polished Gold Suit Jacket Buttons
    const buttonGeo = new THREE.CylinderGeometry(0.024, 0.024, 0.018, 16);
    buttonGeo.rotateX(Math.PI / 2);

    const topButton = new THREE.Mesh(buttonGeo, goldMat);
    topButton.position.set(0, 0.08, 0.74);
    suitGroup.add(topButton);

    const botButton = new THREE.Mesh(buttonGeo, goldMat);
    botButton.position.set(0, -0.06, 0.73);
    suitGroup.add(botButton);

    // 6. Chest Welt Pocket & Folded White Silk Pocket Square
    const pocketWeltGeo = new THREE.BoxGeometry(0.11, 0.016, 0.02);
    const pocketWelt = new THREE.Mesh(pocketWeltGeo, deepNavyMat);
    pocketWelt.position.set(-0.25, 0.18, 0.65);
    pocketWelt.rotation.set(-0.14, 0.35, 0.12);
    suitGroup.add(pocketWelt);

    const squareGeo = new THREE.ConeGeometry(0.045, 0.05, 4);
    const pocketSquare = new THREE.Mesh(squareGeo, whiteFabricMat);
    pocketSquare.position.set(-0.25, 0.21, 0.65);
    pocketSquare.rotation.set(-0.14, 0.35, 0.12);
    suitGroup.add(pocketSquare);

    // 7. Polished Gold Seller Genie Pin on Left Lapel
    const pinGeo = new THREE.CylinderGeometry(0.022, 0.022, 0.01, 16);
    pinGeo.rotateX(Math.PI / 2);
    const lapelPin = new THREE.Mesh(pinGeo, goldMat);
    lapelPin.position.set(-0.22, 0.35, 0.65);
    suitGroup.add(lapelPin);

    // ==========================================
    // Dress Shirt Collar & Power Silk Necktie
    // ==========================================
    const tieGroup = new THREE.Group();
    tieGroup.position.set(0, 0.44, 0.45);
    characterGroup.add(tieGroup);

    // White Shirt Collar Band
    const collarGeo = new THREE.TorusGeometry(0.38, 0.048, 12, 32);
    collarGeo.scale(1.0, 0.4, 1.0);
    const collarMesh = new THREE.Mesh(collarGeo, whiteFabricMat);
    collarMesh.position.set(0, 0.04, -0.1);
    collarMesh.rotation.x = Math.PI / 2.4;
    tieGroup.add(collarMesh);

    // Left Shirt Collar Wing
    const leftCollarWingGeo = new THREE.ConeGeometry(0.065, 0.13, 3);
    const leftCollarWing = new THREE.Mesh(leftCollarWingGeo, whiteFabricMat);
    leftCollarWing.position.set(-0.08, 0.02, 0.14);
    leftCollarWing.rotation.set(-0.2, 0.3, 2.4);
    tieGroup.add(leftCollarWing);

    // Right Shirt Collar Wing
    const rightCollarWingGeo = new THREE.ConeGeometry(0.065, 0.13, 3);
    const rightCollarWing = new THREE.Mesh(rightCollarWingGeo, whiteFabricMat);
    rightCollarWing.position.set(0.08, 0.02, 0.14);
    rightCollarWing.rotation.set(-0.2, -0.3, -2.4);
    tieGroup.add(rightCollarWing);

    // Tie Knot (Crimson Silk)
    const knotGeo = new THREE.CylinderGeometry(0.065, 0.042, 0.08, 16);
    const knotMesh = new THREE.Mesh(knotGeo, tieMat);
    knotMesh.position.set(0, 0.015, 0.14);
    tieGroup.add(knotMesh);

    // Tie Body
    const tieBodyGeo = new THREE.BoxGeometry(0.088, 0.33, 0.02);
    const tieMesh = new THREE.Mesh(tieBodyGeo, tieMat);
    tieMesh.position.set(0, -0.17, 0.16);
    tieMesh.rotation.x = -0.18;
    tieGroup.add(tieMesh);

    // Polished Gold Tie Clip
    const clipGeo = new THREE.BoxGeometry(0.07, 0.012, 0.014);
    const clipMesh = new THREE.Mesh(clipGeo, goldMat);
    clipMesh.position.set(0, -0.12, 0.18);
    tieGroup.add(clipMesh);

    // ==========================================
    // FULL VISIBLE LEGS & GROUNDED OXFORD SHOES
    // ==========================================
    const legSuitGeo = new THREE.CylinderGeometry(0.18, 0.16, 0.44, 20);
    const pantHemGeo = new THREE.TorusGeometry(0.165, 0.02, 12, 24);
    const ankleGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.08, 16);
    const shoeUpperGeo = new THREE.SphereGeometry(0.175, 16, 16);
    shoeUpperGeo.scale(0.9, 0.58, 1.35);
    const soleGeo = new THREE.BoxGeometry(0.32, 0.038, 0.46);

    // Left Leg
    const leftLegGroup = new THREE.Group();
    leftLegGroup.position.set(-0.32, -0.42, 0.05);
    characterGroup.add(leftLegGroup);

    const leftPants = new THREE.Mesh(legSuitGeo, richBlueSuitMat);
    leftPants.position.y = 0.06;
    leftLegGroup.add(leftPants);

    const leftHem = new THREE.Mesh(pantHemGeo, deepNavyMat);
    leftHem.position.y = -0.14;
    leftHem.rotation.x = Math.PI / 2;
    leftLegGroup.add(leftHem);

    const leftAnkle = new THREE.Mesh(ankleGeo, doughMat);
    leftAnkle.position.y = -0.18;
    leftLegGroup.add(leftAnkle);

    const shoeGroupLeft = new THREE.Group();
    shoeGroupLeft.position.set(0, -0.25, 0.06);

    const leftShoe = new THREE.Mesh(shoeUpperGeo, shoeMat);
    shoeGroupLeft.add(leftShoe);

    const leftSole = new THREE.Mesh(soleGeo, shoeMat);
    leftSole.position.set(0, -0.07, 0.02);
    shoeGroupLeft.add(leftSole);

    leftLegGroup.add(shoeGroupLeft);

    // Right Leg
    const rightLegGroup = new THREE.Group();
    rightLegGroup.position.set(0.32, -0.42, 0.05);
    characterGroup.add(rightLegGroup);

    const rightPants = new THREE.Mesh(legSuitGeo, richBlueSuitMat);
    rightPants.position.y = 0.06;
    rightLegGroup.add(rightPants);

    const rightHem = new THREE.Mesh(pantHemGeo, deepNavyMat);
    rightHem.position.y = -0.14;
    rightHem.rotation.x = Math.PI / 2;
    rightLegGroup.add(rightHem);

    const rightAnkle = new THREE.Mesh(ankleGeo, doughMat);
    rightAnkle.position.y = -0.18;
    rightLegGroup.add(rightAnkle);

    const shoeGroupRight = new THREE.Group();
    shoeGroupRight.position.set(0, -0.25, 0.06);

    const rightShoe = new THREE.Mesh(shoeUpperGeo, shoeMat);
    shoeGroupRight.add(rightShoe);

    const rightSole = new THREE.Mesh(soleGeo, shoeMat);
    rightSole.position.set(0, -0.07, 0.02);
    shoeGroupRight.add(rightSole);

    rightLegGroup.add(shoeGroupRight);

    // ==========================================
    // Head Group (Authentic Doughboy Head & Face)
    // ==========================================
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 0.92, 0.06);
    characterGroup.add(headGroup);

    // Head Sphere
    const headGeo = new THREE.SphereGeometry(0.62, 32, 32);
    headGeo.scale(1.08, 0.98, 1.02);
    const headMesh = new THREE.Mesh(headGeo, doughMat);
    headGroup.add(headMesh);

    // Cheeks
    const cheekGeo = new THREE.SphereGeometry(0.16, 16, 16);
    cheekGeo.scale(1.2, 0.85, 0.45);

    const leftCheek = new THREE.Mesh(cheekGeo, cheekMat);
    leftCheek.position.set(-0.35, -0.08, 0.54);
    leftCheek.rotation.y = -0.25;
    headGroup.add(leftCheek);

    const rightCheek = new THREE.Mesh(cheekGeo, cheekMat);
    rightCheek.position.set(0.35, -0.08, 0.54);
    rightCheek.rotation.y = 0.25;
    headGroup.add(rightCheek);

    // Button Nose
    const noseGeo = new THREE.SphereGeometry(0.075, 20, 20);
    noseGeo.scale(1.15, 0.95, 0.9);
    const noseMesh = new THREE.Mesh(noseGeo, doughMat);
    noseMesh.position.set(0, -0.03, 0.63);
    headGroup.add(noseMesh);

    // Eyes
    const eyeScleraGeo = new THREE.SphereGeometry(0.105, 24, 24);
    eyeScleraGeo.scale(0.9, 1.05, 0.65);

    // Left Eye
    const leftEyeGroup = new THREE.Group();
    leftEyeGroup.position.set(-0.21, 0.11, 0.56);
    const leftIris = new THREE.Mesh(eyeScleraGeo, eyeBlueMat);
    leftEyeGroup.add(leftIris);

    const pupilGeo = new THREE.SphereGeometry(0.055, 16, 16);
    pupilGeo.scale(1.0, 1.0, 0.3);
    const leftPupil = new THREE.Mesh(pupilGeo, pupilMat);
    leftPupil.position.set(0, 0, 0.055);
    leftEyeGroup.add(leftPupil);

    const shineGeo1 = new THREE.SphereGeometry(0.026, 12, 12);
    const leftShine1 = new THREE.Mesh(shineGeo1, eyeHighlightMat);
    leftShine1.position.set(-0.025, 0.035, 0.07);
    leftEyeGroup.add(leftShine1);

    const shineGeo2 = new THREE.SphereGeometry(0.012, 10, 10);
    const leftShine2 = new THREE.Mesh(shineGeo2, eyeHighlightMat);
    leftShine2.position.set(0.025, -0.025, 0.07);
    leftEyeGroup.add(leftShine2);

    headGroup.add(leftEyeGroup);

    // Right Eye
    const rightEyeGroup = new THREE.Group();
    rightEyeGroup.position.set(0.21, 0.11, 0.56);
    const rightIris = new THREE.Mesh(eyeScleraGeo, eyeBlueMat);
    rightEyeGroup.add(rightIris);

    const rightPupil = new THREE.Mesh(pupilGeo, pupilMat);
    rightPupil.position.set(0, 0, 0.055);
    rightEyeGroup.add(rightPupil);

    const rightShine1 = new THREE.Mesh(shineGeo1, eyeHighlightMat);
    rightShine1.position.set(-0.025, 0.035, 0.07);
    rightEyeGroup.add(rightShine1);

    const rightShine2 = new THREE.Mesh(shineGeo2, eyeHighlightMat);
    rightShine2.position.set(0.025, -0.025, 0.07);
    rightEyeGroup.add(rightShine2);

    headGroup.add(rightEyeGroup);

    // Smart Analyst Glasses
    const glassesGroup = new THREE.Group();
    glassesGroup.position.set(0, 0.11, 0.63);
    headGroup.add(glassesGroup);

    const rimGeo = new THREE.TorusGeometry(0.125, 0.012, 12, 32);
    const leftRim = new THREE.Mesh(rimGeo, glassesFrameMat);
    leftRim.position.set(-0.21, 0, 0);
    glassesGroup.add(leftRim);

    const lensGeo = new THREE.CircleGeometry(0.122, 24);
    const leftLens = new THREE.Mesh(lensGeo, glassesLensMat);
    leftLens.position.set(-0.21, 0, 0);
    glassesGroup.add(leftLens);

    const rightRim = new THREE.Mesh(rimGeo, glassesFrameMat);
    rightRim.position.set(0.21, 0, 0);
    glassesGroup.add(rightRim);

    const rightLens = new THREE.Mesh(lensGeo, glassesLensMat);
    rightLens.position.set(0.21, 0, 0);
    glassesGroup.add(rightLens);

    const bridgeGeo = new THREE.BoxGeometry(0.11, 0.014, 0.018);
    const bridge = new THREE.Mesh(bridgeGeo, glassesFrameMat);
    bridge.position.set(0, 0.03, 0.01);
    glassesGroup.add(bridge);

    const templeGeo = new THREE.BoxGeometry(0.01, 0.01, 0.38);
    const leftTemple = new THREE.Mesh(templeGeo, glassesFrameMat);
    leftTemple.position.set(-0.35, 0.015, -0.16);
    leftTemple.rotation.y = 0.16;
    glassesGroup.add(leftTemple);

    const rightTemple = new THREE.Mesh(templeGeo, glassesFrameMat);
    rightTemple.position.set(0.35, 0.015, -0.16);
    rightTemple.rotation.y = -0.16;
    glassesGroup.add(rightTemple);

    // Mouth
    const mouthGroup = new THREE.Group();
    mouthGroup.position.set(0, -0.19, 0.58);
    headGroup.add(mouthGroup);

    const mouthCavityGeo = new THREE.CylinderGeometry(0.14, 0.18, 0.08, 24);
    mouthCavityGeo.scale(1.25, 0.9, 0.5);
    const mouthMesh = new THREE.Mesh(mouthCavityGeo, mouthInteriorMat);
    mouthMesh.rotation.x = Math.PI / 2;
    mouthGroup.add(mouthMesh);

    const tongueGeo = new THREE.SphereGeometry(0.09, 16, 16);
    tongueGeo.scale(1.2, 0.6, 0.8);
    const tongueMesh = new THREE.Mesh(tongueGeo, tongueMat);
    tongueMesh.position.set(0, -0.04, 0.02);
    mouthGroup.add(tongueMesh);

    // Hat
    const hatGroup = new THREE.Group();
    hatGroup.position.set(0, 0.52, -0.06);
    hatGroup.rotation.x = -0.1;
    headGroup.add(hatGroup);

    const bandGeo = new THREE.CylinderGeometry(0.44, 0.48, 0.28, 32);
    const bandMesh = new THREE.Mesh(bandGeo, whiteFabricMat);
    hatGroup.add(bandMesh);

    const logoOvalGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.02, 24);
    logoOvalGeo.scale(1.35, 0.15, 0.9);
    const logoMesh = new THREE.Mesh(logoOvalGeo, logoBlueMat);
    logoMesh.position.set(0, 0.02, 0.47);
    logoMesh.rotation.x = Math.PI / 2;
    hatGroup.add(logoMesh);

    const starGeo = new THREE.SphereGeometry(0.04, 12, 12);
    starGeo.scale(1.2, 0.4, 1.2);
    const starMesh = new THREE.Mesh(starGeo, goldMat);
    starMesh.position.set(0, 0.02, 0.49);
    hatGroup.add(starMesh);

    const pleatFluteGroup = new THREE.Group();
    pleatFluteGroup.position.set(0, 0.35, 0);
    hatGroup.add(pleatFluteGroup);

    const fluteCount = 14;
    for (let i = 0; i < fluteCount; i++) {
      const angle = (i / fluteCount) * Math.PI * 2;
      const radiusBottom = 0.43;
      const radiusTop = 0.54;
      
      const fluteGeo = new THREE.CylinderGeometry(0.075, 0.06, 0.52, 12);
      const fluteMesh = new THREE.Mesh(fluteGeo, whiteFabricMat);
      
      const xMid = Math.cos(angle) * (radiusBottom + radiusTop) * 0.5;
      const zMid = Math.sin(angle) * (radiusBottom + radiusTop) * 0.5;
      fluteMesh.position.set(xMid, 0, zMid);
      fluteMesh.rotation.y = -angle;
      pleatFluteGroup.add(fluteMesh);
    }

    const pleatCoreGeo = new THREE.CylinderGeometry(0.5, 0.42, 0.5, 24);
    const pleatCore = new THREE.Mesh(pleatCoreGeo, whiteFabricMat);
    pleatFluteGroup.add(pleatCore);

    const puffGeo = new THREE.SphereGeometry(0.58, 32, 24);
    puffGeo.scale(1.18, 0.85, 1.15);
    const puffMesh = new THREE.Mesh(puffGeo, whiteFabricMat);
    puffMesh.position.set(0, 0.62, 0.02);
    hatGroup.add(puffMesh);

    // ==========================================
    // ANATOMICALLY CONSISTENT ARMS & SCULPTED HANDS
    // Both arms extend along -Y from shoulder with full fingers & thumbs
    // ==========================================
    const sleeveGeo = new THREE.CylinderGeometry(0.14, 0.17, 0.44, 16);
    const cuffGeo = new THREE.CylinderGeometry(0.142, 0.142, 0.06, 16);
    const cuffButtonGeo = new THREE.CylinderGeometry(0.014, 0.014, 0.012, 12);
    cuffButtonGeo.rotateZ(Math.PI / 2);

    const palmGeo = new THREE.SphereGeometry(0.125, 16, 16);
    palmGeo.scale(1.0, 1.15, 0.72);
    const thumbGeo = new THREE.SphereGeometry(0.048, 12, 12);
    thumbGeo.scale(0.85, 1.35, 0.85);
    const fingerGeo = new THREE.SphereGeometry(0.04, 12, 12);
    fingerGeo.scale(0.82, 1.3, 0.82);

    // ------------------------------------------
    // LEFT ARM & HAND
    // ------------------------------------------
    const leftArmGroup = new THREE.Group();
    leftArmGroup.position.set(-0.54, 0.22, 0.05);
    characterGroup.add(leftArmGroup);

    const leftSleeve = new THREE.Mesh(sleeveGeo, richBlueSuitMat);
    leftSleeve.position.y = -0.18;
    leftArmGroup.add(leftSleeve);

    const leftCuff = new THREE.Mesh(cuffGeo, whiteFabricMat);
    leftCuff.position.y = -0.38;
    leftArmGroup.add(leftCuff);

    const leftCuffButton = new THREE.Mesh(cuffButtonGeo, goldMat);
    leftCuffButton.position.set(-0.13, -0.32, 0);
    leftArmGroup.add(leftCuffButton);

    const leftHandGroup = new THREE.Group();
    leftHandGroup.position.set(0, -0.46, 0);
    leftArmGroup.add(leftHandGroup);

    const leftPalm = new THREE.Mesh(palmGeo, doughMat);
    leftHandGroup.add(leftPalm);

    // Opposable Left Thumb
    const leftThumb = new THREE.Mesh(thumbGeo, doughMat);
    leftThumb.position.set(0.09, -0.02, 0.04);
    leftThumb.rotation.set(0.2, 0, -0.75);
    leftHandGroup.add(leftThumb);

    // 4 Sculpted Left Fingers
    const leftFinger1 = new THREE.Mesh(fingerGeo, doughMat);
    leftFinger1.position.set(-0.06, -0.12, 0.01);
    leftFinger1.rotation.z = 0.12;
    leftHandGroup.add(leftFinger1);

    const leftFinger2 = new THREE.Mesh(fingerGeo, doughMat);
    leftFinger2.position.set(-0.01, -0.14, 0.01);
    leftHandGroup.add(leftFinger2);

    const leftFinger3 = new THREE.Mesh(fingerGeo, doughMat);
    leftFinger3.position.set(0.04, -0.12, 0.01);
    leftFinger3.rotation.z = -0.12;
    leftHandGroup.add(leftFinger3);

    const leftFinger4 = new THREE.Mesh(fingerGeo, doughMat);
    leftFinger4.position.set(0.09, -0.09, 0.01);
    leftFinger4.rotation.z = -0.28;
    leftHandGroup.add(leftFinger4);

    // ------------------------------------------
    // RIGHT ARM & HAND
    // ------------------------------------------
    const rightArmGroup = new THREE.Group();
    rightArmGroup.position.set(0.54, 0.22, 0.05);
    characterGroup.add(rightArmGroup);

    const rightSleeve = new THREE.Mesh(sleeveGeo, richBlueSuitMat);
    rightSleeve.position.y = -0.18;
    rightArmGroup.add(rightSleeve);

    const rightCuff = new THREE.Mesh(cuffGeo, whiteFabricMat);
    rightCuff.position.y = -0.38;
    rightArmGroup.add(rightCuff);

    const rightCuffButton = new THREE.Mesh(cuffButtonGeo, goldMat);
    rightCuffButton.position.set(0.13, -0.32, 0);
    rightArmGroup.add(rightCuffButton);

    const rightHandGroup = new THREE.Group();
    rightHandGroup.position.set(0, -0.46, 0);
    rightArmGroup.add(rightHandGroup);

    const rightPalm = new THREE.Mesh(palmGeo, doughMat);
    rightHandGroup.add(rightPalm);

    // Opposable Right Thumb
    const rightThumb = new THREE.Mesh(thumbGeo, doughMat);
    rightThumb.position.set(-0.09, -0.02, 0.04);
    rightThumb.rotation.set(0.2, 0, 0.75);
    rightHandGroup.add(rightThumb);

    // 4 Sculpted Right Fingers
    const rightFinger1 = new THREE.Mesh(fingerGeo, doughMat);
    rightFinger1.position.set(0.06, -0.12, 0.01);
    rightFinger1.rotation.z = -0.12;
    rightHandGroup.add(rightFinger1);

    const rightFinger2 = new THREE.Mesh(fingerGeo, doughMat);
    rightFinger2.position.set(0.01, -0.14, 0.01);
    rightHandGroup.add(rightFinger2);

    const rightFinger3 = new THREE.Mesh(fingerGeo, doughMat);
    rightFinger3.position.set(-0.04, -0.12, 0.01);
    rightFinger3.rotation.z = 0.12;
    rightHandGroup.add(rightFinger3);

    const rightFinger4 = new THREE.Mesh(fingerGeo, doughMat);
    rightFinger4.position.set(-0.09, -0.09, 0.01);
    rightFinger4.rotation.z = 0.28;
    rightHandGroup.add(rightFinger4);

    // ==========================================
    // Mouse Interaction on Hover
    // ==========================================
    let mouseX = 0;
    let mouseY = 0;
    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const ny = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mouseX = THREE.MathUtils.clamp(nx, -1, 1);
      mouseY = THREE.MathUtils.clamp(ny, -1, 1);
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || size;
      const h = container.clientHeight || size;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // ==========================================
    // Animation Loop
    // ==========================================
    let animationFrameId: number;
    let clock = new THREE.Clock();
    let blinkTimer = 0;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();
      const speaking = isSpeakingRef.current;

      // 1. Gentle Doughboy breathing bounce
      const breath = Math.sin(elapsedTime * 2.2) * 0.016;
      characterGroup.position.y = -0.15 + breath;
      bodyMesh.scale.set(1.02 + breath * 0.35, 1.12 - breath * 0.2, 0.98 + breath * 0.35);

      // 2. Interactive Head Tracking with smooth lerp
      const targetHeadRotY = mouseX * 0.32 + (speaking ? Math.sin(elapsedTime * 4.2) * 0.05 : 0);
      const targetHeadRotX = -mouseY * 0.18 + (speaking ? Math.cos(elapsedTime * 3.6) * 0.04 : 0);
      headGroup.rotation.y = THREE.MathUtils.lerp(headGroup.rotation.y, targetHeadRotY, 0.08);
      headGroup.rotation.x = THREE.MathUtils.lerp(headGroup.rotation.x, targetHeadRotX, 0.08);
      headGroup.rotation.z = Math.sin(elapsedTime * 1.6) * 0.02;

      // 3. Telemetry rings rotation
      telemetryGroup.rotation.z = elapsedTime * 0.12;
      ringMesh2.rotation.y = elapsedTime * 0.18;

      // 4. Tall Hat gentle realistic wobble
      hatGroup.rotation.z = Math.sin(elapsedTime * 2.2) * 0.02;

      // =========================================================
      // 5. DUAL-HAND EXPLANATORY GESTURES (BOTH HANDS ACTIVE!)
      // =========================================================
      if (speaking) {
        // Conversational advisory gestures: BOTH arms lift forward and explain simultaneously!
        const beatSlow = Math.sin(elapsedTime * 2.6);
        const beatFast = Math.sin(elapsedTime * 4.4);
        const pulseBoth = Math.sin(elapsedTime * 3.2);

        // BOTH ARMS LIFT FORWARD IN FRONT OF CHEST TO EXPLAIN
        // Left Arm: reaches forward towards viewer and sweeps expressively
        const targetLeftArmX = -0.85 + beatFast * 0.18;
        const targetLeftArmZ = 0.42 + beatSlow * 0.16;
        const targetLeftArmY = 0.25 + pulseBoth * 0.14;

        leftArmGroup.rotation.x = THREE.MathUtils.lerp(leftArmGroup.rotation.x, targetLeftArmX, 0.12);
        leftArmGroup.rotation.z = THREE.MathUtils.lerp(leftArmGroup.rotation.z, targetLeftArmZ, 0.12);
        leftArmGroup.rotation.y = THREE.MathUtils.lerp(leftArmGroup.rotation.y, targetLeftArmY, 0.12);

        // Right Arm: reaches forward towards viewer and sweeps expressively in tandem
        const targetRightArmX = -0.85 + Math.cos(elapsedTime * 4.4) * 0.18;
        const targetRightArmZ = -0.42 - beatSlow * 0.16;
        const targetRightArmY = -0.25 - pulseBoth * 0.14;

        rightArmGroup.rotation.x = THREE.MathUtils.lerp(rightArmGroup.rotation.x, targetRightArmX, 0.12);
        rightArmGroup.rotation.z = THREE.MathUtils.lerp(rightArmGroup.rotation.z, targetRightArmZ, 0.12);
        rightArmGroup.rotation.y = THREE.MathUtils.lerp(rightArmGroup.rotation.y, targetRightArmY, 0.12);

        // Left Hand: Wrist rotates open with palm facing upward/inward to present metrics
        const targetLeftHandX = 0.45 + beatFast * 0.25;
        const targetLeftHandY = 0.55 + beatSlow * 0.22;
        const targetLeftHandZ = -pulseBoth * 0.18;

        leftHandGroup.rotation.x = THREE.MathUtils.lerp(leftHandGroup.rotation.x, targetLeftHandX, 0.14);
        leftHandGroup.rotation.y = THREE.MathUtils.lerp(leftHandGroup.rotation.y, targetLeftHandY, 0.14);
        leftHandGroup.rotation.z = THREE.MathUtils.lerp(leftHandGroup.rotation.z, targetLeftHandZ, 0.14);

        // Right Hand: Wrist rotates open with palm facing upward/inward to present metrics
        const targetRightHandX = 0.45 + Math.cos(elapsedTime * 4.4) * 0.25;
        const targetRightHandY = -0.55 - beatSlow * 0.22;
        const targetRightHandZ = pulseBoth * 0.18;

        rightHandGroup.rotation.x = THREE.MathUtils.lerp(rightHandGroup.rotation.x, targetRightHandX, 0.14);
        rightHandGroup.rotation.y = THREE.MathUtils.lerp(rightHandGroup.rotation.y, targetRightHandY, 0.14);
        rightHandGroup.rotation.z = THREE.MathUtils.lerp(rightHandGroup.rotation.z, targetRightHandZ, 0.14);

        // Both hands expand and flex with speech phrase emphasis
        const handFlex = 1.0 + Math.max(0, Math.sin(elapsedTime * 3.8)) * 0.16;
        leftHandGroup.scale.set(handFlex, handFlex, handFlex);
        rightHandGroup.scale.set(handFlex, handFlex, handFlex);

        // Torso communicative cadence
        characterGroup.rotation.z = THREE.MathUtils.lerp(characterGroup.rotation.z, beatSlow * 0.035, 0.1);
      } else {
        // IDLE STATE: Smoothly return to signature Doughboy pose
        // Right Arm: Enthusiastic high friendly wave up in the air
        const waveOsc = Math.sin(elapsedTime * 2.8) * 0.18;
        rightArmGroup.rotation.z = THREE.MathUtils.lerp(rightArmGroup.rotation.z, 2.25 + waveOsc, 0.08);
        rightArmGroup.rotation.x = THREE.MathUtils.lerp(rightArmGroup.rotation.x, -0.22, 0.08);
        rightArmGroup.rotation.y = THREE.MathUtils.lerp(rightArmGroup.rotation.y, 0, 0.08);

        // Right Hand: Waving wrist motion
        rightHandGroup.rotation.x = THREE.MathUtils.lerp(rightHandGroup.rotation.x, 0, 0.08);
        rightHandGroup.rotation.y = THREE.MathUtils.lerp(rightHandGroup.rotation.y, 0, 0.08);
        rightHandGroup.rotation.z = THREE.MathUtils.lerp(rightHandGroup.rotation.z, Math.sin(elapsedTime * 3.6) * 0.22, 0.08);
        rightHandGroup.scale.set(1.0, 1.0, 1.0);

        // Left Arm: Gently rests naturally along side/hip
        leftArmGroup.rotation.z = THREE.MathUtils.lerp(leftArmGroup.rotation.z, 0.35, 0.08);
        leftArmGroup.rotation.x = THREE.MathUtils.lerp(leftArmGroup.rotation.x, 0.15, 0.08);
        leftArmGroup.rotation.y = THREE.MathUtils.lerp(leftArmGroup.rotation.y, 0, 0.08);

        // Left Hand: Relaxed neutral
        leftHandGroup.rotation.x = THREE.MathUtils.lerp(leftHandGroup.rotation.x, 0, 0.08);
        leftHandGroup.rotation.y = THREE.MathUtils.lerp(leftHandGroup.rotation.y, 0, 0.08);
        leftHandGroup.rotation.z = THREE.MathUtils.lerp(leftHandGroup.rotation.z, 0, 0.08);
        leftHandGroup.scale.set(1.0, 1.0, 1.0);

        characterGroup.rotation.z = THREE.MathUtils.lerp(characterGroup.rotation.z, 0, 0.08);
      }

      // 6. Joyful Smile & Speech articulation
      if (speaking) {
        const mouthOpen = 0.8 + Math.abs(Math.sin(elapsedTime * 12.0)) * 1.3;
        const mouthWidth = 1.05 + Math.sin(elapsedTime * 9.0) * 0.2;
        mouthMesh.scale.set(mouthWidth * 1.25, mouthOpen * 0.9, 0.5);
        tongueMesh.position.y = -0.04 + Math.sin(elapsedTime * 10.0) * 0.02;
      } else {
        mouthMesh.scale.set(1.25, 0.65 + Math.sin(elapsedTime * 1.5) * 0.04, 0.5);
        tongueMesh.position.y = -0.04;
      }

      // 7. Natural Eye Blinking
      blinkTimer += 0.016;
      if (blinkTimer > 3.4) {
        leftIris.scale.y = 0.12;
        rightIris.scale.y = 0.12;
        leftPupil.scale.y = 0.12;
        rightPupil.scale.y = 0.12;
        if (blinkTimer > 3.55) {
          leftIris.scale.y = 1.05;
          rightIris.scale.y = 1.05;
          leftPupil.scale.y = 1.0;
          rightPupil.scale.y = 1.0;
          blinkTimer = Math.random() * 0.8;
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    // Cleanup
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      renderer.dispose();
      scene.clear();
      if (container) {
        container.innerHTML = '';
      }
    };
  }, [size]);

  return (
    <div
      ref={mountRef}
      onClick={onClick}
      className={`relative cursor-pointer select-none transition-transform active:scale-95 ${className}`}
      style={{ width: `${size}px`, height: `${size}px` }}
      title="Click 3D Live Seller Genie to speak or pause analysis"
    />
  );
};
