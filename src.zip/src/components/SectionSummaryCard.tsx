import React, { useState } from 'react';
import { 
  AlertCircle, 
  HelpCircle, 
  Zap, 
  ArrowUpRight, 
  TrendingDown, 
  TrendingUp, 
  CheckCircle2,
  Sparkles,
  Search,
  Activity,
  MessageSquareQuote,
  Lightbulb,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { DashboardTranslations } from '../utils/translations';

export interface SectionSummaryItem {
  headline: string;
  description: string;
  keyMetric?: string;
  trend?: 'down' | 'up' | 'neutral';
  impact?: string;
  category?: string;
}

export interface SectionSummaryAction {
  headline: string;
  description: string;
  actionTitle?: string;
  actionType?: string;
  onExecute?: () => void;
  estimatedLift?: string;
}

export interface PlainSellerWords {
  summary: string;
  actionTip?: string;
}

interface SectionSummaryCardProps {
  sectionName: string;
  whatHappened: SectionSummaryItem;
  why: SectionSummaryItem;
  nextBestAction: SectionSummaryAction;
  plainSellerWords?: PlainSellerWords;
  translations?: DashboardTranslations;
  className?: string;
}

export const SectionSummaryCard: React.FC<SectionSummaryCardProps> = ({
  sectionName,
  whatHappened,
  why,
  nextBestAction,
  plainSellerWords,
  translations,
  className = '',
}) => {
  const [isPlainWordsOpen, setIsPlainWordsOpen] = useState<boolean>(true);

  const tExecutive = translations?.executiveSummary || 'Executive Summary';
  const tBrief = translations?.diagnosticBrief || 'Diagnostic Brief';
  const tWhat = translations?.whatHappened || '1. What Happened';
  const tWhy = translations?.whyRootCause || '2. Why (Root Cause)';
  const tAction = translations?.nextBestAction || '3. Next Best Action';
  const tPlainWords = translations?.plainSellerWordsTitle || 'Simplified Explanation';
  const tObserved = translations?.observedImpact || 'Observed Impact:';
  const tDriver = translations?.primaryDriver || 'Primary Driver:';
  const tPrescriptive = translations?.prescriptiveResolution || 'Prescriptive resolution';
  const tExecute = translations?.executeAction || 'Execute Action';

  return (
    <div className={`mt-6 pt-5 border-t border-slate-200 dark:border-slate-800 ${className}`}>
      {/* Summary Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded-md bg-amber-500/10 text-amber-600 dark:text-amber-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>{sectionName} — {tExecutive}</span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                {tBrief}
              </span>
            </h4>
          </div>
        </div>
        <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-sky-500" /> {tWhat.replace(/^\d+\.\s*/, '')}
          <span className="text-slate-300 dark:text-slate-600">•</span>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500" /> {tWhy.replace(/^\d+\.\s*/, '')}
          <span className="text-slate-300 dark:text-slate-600">•</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> {tAction.replace(/^\d+\.\s*/, '')}
        </div>
      </div>

      {/* 3-Column Diagnostic Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
        
        {/* 1. WHAT HAPPENED */}
        <div className="relative flex flex-col justify-between p-4 rounded-xl bg-slate-50/80 dark:bg-slate-950/70 border border-slate-200 dark:border-slate-800/90 shadow-2xs hover:border-sky-500/40 transition-colors group">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-sky-500/10 text-sky-700 dark:text-sky-400 text-[10.5px] font-bold tracking-wide uppercase border border-sky-500/20">
                <Activity className="w-3 h-3" />
                {tWhat}
              </span>
              {whatHappened.trend === 'down' && (
                <span className="inline-flex items-center gap-0.5 text-[11px] font-bold text-rose-600 dark:text-rose-400 bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/20">
                  <TrendingDown className="w-3 h-3" />
                  {whatHappened.keyMetric}
                </span>
              )}
              {whatHappened.trend === 'up' && (
                <span className="inline-flex items-center gap-0.5 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                  <TrendingUp className="w-3 h-3" />
                  {whatHappened.keyMetric}
                </span>
              )}
            </div>

            <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100 leading-snug">
              {whatHappened.headline}
            </h5>
            <p className="text-[11.5px] text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">
              {whatHappened.description}
            </p>
          </div>

          {whatHappened.impact && (
            <div className="mt-3 pt-2 border-t border-slate-200/80 dark:border-slate-800 text-[10.5px] text-slate-500 dark:text-slate-400 flex items-center gap-1 font-medium">
              <span className="text-slate-400 dark:text-slate-500">{tObserved}</span>
              <span className="font-bold text-slate-700 dark:text-slate-200">{whatHappened.impact}</span>
            </div>
          )}
        </div>

        {/* 2. WHY (ROOT CAUSE) */}
        <div className="relative flex flex-col justify-between p-4 rounded-xl bg-amber-500/[0.04] dark:bg-amber-500/[0.07] border border-amber-500/20 dark:border-amber-500/30 shadow-2xs hover:border-amber-500/50 transition-colors group">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-700 dark:text-amber-300 text-[10.5px] font-bold tracking-wide uppercase border border-amber-500/25">
                <Search className="w-3 h-3" />
                {tWhy}
              </span>
              {why.category && (
                <span className="text-[10px] font-semibold text-amber-600 dark:text-amber-400 px-1.5 py-0.5 rounded bg-amber-500/10">
                  {why.category}
                </span>
              )}
            </div>

            <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100 leading-snug">
              {why.headline}
            </h5>
            <p className="text-[11.5px] text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">
              {why.description}
            </p>
          </div>

          {why.impact && (
            <div className="mt-3 pt-2 border-t border-amber-500/15 text-[10.5px] text-slate-500 dark:text-slate-400 flex items-center gap-1 font-medium">
              <span className="text-amber-600/80 dark:text-amber-400/80 font-semibold">{tDriver}</span>
              <span className="font-bold text-slate-700 dark:text-slate-200 truncate">{why.impact}</span>
            </div>
          )}
        </div>

        {/* 3. NEXT BEST ACTION */}
        <div className="relative flex flex-col justify-between p-4 rounded-xl bg-emerald-500/[0.04] dark:bg-emerald-500/[0.07] border border-emerald-500/20 dark:border-emerald-500/30 shadow-2xs hover:border-emerald-500/50 transition-colors group">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-[10.5px] font-bold tracking-wide uppercase border border-emerald-500/25">
                <Zap className="w-3 h-3" />
                {tAction}
              </span>
              {nextBestAction.estimatedLift && (
                <span className="text-[10px] font-extrabold text-emerald-700 dark:text-emerald-400 bg-emerald-500/15 px-1.5 py-0.5 rounded border border-emerald-500/20">
                  {nextBestAction.estimatedLift}
                </span>
              )}
            </div>

            <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100 leading-snug">
              {nextBestAction.headline}
            </h5>
            <p className="text-[11.5px] text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">
              {nextBestAction.description}
            </p>
          </div>

          <div className="mt-3 pt-2.5 border-t border-emerald-500/15 flex items-center justify-between gap-2">
            <span className="text-[10px] text-emerald-700/80 dark:text-emerald-400/80 font-medium">
              {tPrescriptive}
            </span>

            {nextBestAction.onExecute && (
              <button
                onClick={nextBestAction.onExecute}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10.5px] transition-all cursor-pointer shadow-xs active:scale-95 shrink-0"
              >
                <span>{nextBestAction.actionTitle || tExecute}</span>
                <ArrowUpRight className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>

      </div>

      {/* NEW: Plain Seller Words (Simplified Explanation) */}
      {plainSellerWords && (
        <div className="mt-3 p-3.5 rounded-xl bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-400/30 dark:border-amber-500/20">
          <div 
            onClick={() => setIsPlainWordsOpen(!isPlainWordsOpen)}
            className="flex items-center justify-between cursor-pointer select-none"
          >
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                <Lightbulb className="w-3 h-3" />
              </div>
              <span className="text-xs font-bold text-slate-900 dark:text-amber-300 flex items-center gap-1.5">
                {tPlainWords}
                <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-400/30">
                  {translations?.plainSellerWordsBadge || 'Zero Jargon'}
                </span>
              </span>
            </div>
            <button className="text-slate-400 hover:text-slate-200 transition-colors p-0.5">
              {isPlainWordsOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>

          {isPlainWordsOpen && (
            <div className="mt-2 pl-7 space-y-1.5">
              <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed font-normal">
                "{plainSellerWords.summary}"
              </p>
              {plainSellerWords.actionTip && (
                <div className="flex items-baseline gap-1 text-[11px] text-amber-700 dark:text-amber-300 font-semibold pt-1">
                  <span>👉 Quick fix:</span>
                  <span>{plainSellerWords.actionTip}</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
