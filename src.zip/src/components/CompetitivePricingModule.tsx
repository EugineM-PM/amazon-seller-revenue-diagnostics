import React, { useState } from 'react';
import { 
  TrendingDown, 
  TrendingUp, 
  DollarSign, 
  Scale, 
  ShieldCheck, 
  AlertCircle, 
  Sliders, 
  ArrowRight,
  Check
} from 'lucide-react';
import { Currency, ProductItem, TimePeriod } from '../types/seller';
import { formatCurrency, formatPercent, formatPP } from '../utils/formatters';
import { SectionSummaryCard } from './SectionSummaryCard';

interface CompetitivePricingModuleProps {
  products: ProductItem[];
  selectedProductId: string;
  currency: Currency;
  timePeriod: TimePeriod;
  onSelectProduct: (id: string) => void;
  onExecuteAction: (title: string, type: string) => void;
}

export const CompetitivePricingModule: React.FC<CompetitivePricingModuleProps> = ({
  products,
  selectedProductId,
  currency,
  timePeriod,
  onSelectProduct,
  onExecuteAction,
}) => {
  const activeProduct = products.find((p) => p.id === selectedProductId) || products[0];

  const priceDiff = activeProduct.currentPrice - activeProduct.lowestCompetitorPrice;
  const isUndercut = priceDiff > 0;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Competitive Pricing & Buy Box PP Impact
            </h3>
            {isUndercut && (
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900/50">
                Undercut by {formatCurrency(priceDiff, currency)}
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Monitor competitors' price movements, daily volatility, and the resulting Buy Box percentage point delta
          </p>
        </div>

        {/* Product selector */}
        <select
          value={activeProduct.id}
          onChange={(e) => onSelectProduct(e.target.value)}
          className="text-xs font-semibold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 focus:outline-none cursor-pointer self-start sm:self-auto"
        >
          {products.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
      </div>

      {/* Main KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Current Selling Price */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Your Current Selling Price
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {formatCurrency(activeProduct.currentPrice, currency)}
            </span>
            <span className="text-xs font-medium text-slate-400">
              MSRP / Standard
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            Estimated unit profit: ~32% margin
          </span>
        </div>

        {/* Lowest Competitor Price */}
        <div className="p-4 rounded-xl border border-rose-200 dark:border-rose-900/50 bg-rose-50/40 dark:bg-rose-950/20">
          <span className="text-xs font-bold text-rose-900 dark:text-rose-300">
            Lowest Competitor Price
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-rose-600 dark:text-rose-400">
              {formatCurrency(activeProduct.lowestCompetitorPrice, currency)}
            </span>
            {isUndercut && (
              <span className="text-xs font-bold text-rose-600">
                (-{formatCurrency(priceDiff, currency)})
              </span>
            )}
          </div>
          <span className="text-[11px] text-rose-700 dark:text-rose-400">
            Avg Competitor: {formatCurrency(activeProduct.avgCompetitorPrice, currency)}
          </span>
        </div>

        {/* Daily Competitor Price Change Velocity (Required by prompt) */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Daily Competitor Price Velocity
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {formatPercent(activeProduct.competitorPriceDailyChangePct)}
            </span>
            <span className="text-xs font-bold text-amber-600">
              daily shift
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            Average competitor price changed by {formatPercent(activeProduct.competitorPriceDailyChangePct)} on a daily basis
          </span>
        </div>

        {/* Buy Box PP Delta & Revenue Impact */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Buy Box PP Change & Revenue
          </span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className={`text-2xl font-black ${
              activeProduct.buyBoxPPChange < 0 ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'
            }`}>
              {formatPP(activeProduct.buyBoxPPChange)}
            </span>
            <span className="text-xs font-bold text-rose-600">
              {activeProduct.revenueAtRisk > 0 ? `-${formatCurrency(activeProduct.revenueAtRisk, currency)}` : '+AED 0'}
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            Lost or gained revenue impact ({timePeriod})
          </span>
        </div>

      </div>

      {/* Interactive Price Comparison Bar & 1-Click Repricing */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-900 dark:text-white">
              Price War Simulator:
            </span>
            <span className="text-xs text-slate-500">
              Your price: {formatCurrency(activeProduct.currentPrice, currency)} vs Competitor floor: {formatCurrency(activeProduct.lowestCompetitorPrice, currency)}
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Matching competitor at {formatCurrency(activeProduct.lowestCompetitorPrice, currency)} reclaims an estimated <strong>+21 PP in Buy Box</strong> while keeping profit margin at 27.4%.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onExecuteAction(`Matched Lowest Price at ${formatCurrency(activeProduct.lowestCompetitorPrice, currency)} for ${activeProduct.name}`, 'reprice')}
            className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-sm transition-all cursor-pointer whitespace-nowrap"
          >
            Match Lowest Competitor Price
          </button>
          <button
            onClick={() => onExecuteAction(`Configured Dynamic Repricing Floor for ${activeProduct.name}`, 'reprice')}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition-colors cursor-pointer whitespace-nowrap"
          >
            Set Repricer Rule
          </button>
        </div>
      </div>

      {/* Section Summary: What Happened - Why - Next Best Action */}
      <SectionSummaryCard
        sectionName="Pricing & Undercuts"
        whatHappened={{
          headline: `Current listing price of ${formatCurrency(activeProduct.currentPrice, currency)} is undercut by ${formatCurrency(activeProduct.currentPrice - activeProduct.lowestCompetitorPrice, currency)} against lowest rival`,
          description: `Lowest competing 3P seller currently offers ${formatCurrency(activeProduct.lowestCompetitorPrice, currency)}, driving daily margin leakage of approximately ${formatCurrency(1420, currency)} and stripping Buy Box prominence.`,
          keyMetric: `-${formatCurrency(activeProduct.currentPrice - activeProduct.lowestCompetitorPrice, currency)} Undercut`,
          trend: isUndercut ? "down" : "neutral",
          impact: `${formatCurrency(1420, currency)} Daily Margin Leakage`,
        }}
        why={{
          headline: "Rogue 3P seller algorithmic price dumping and regional shipping discount arbitrage",
          description: "Sub-tier sellers are leveraging automated repricing tools programmed to undercut the Buy Box leader by AED 1.00 down to non-MAP compliant thresholds, capturing price-sensitive shoppers.",
          category: "MAP Compliance & Price War",
          impact: "Primary Driver: Automated 3P seller undercut loop bypassing brand MAP",
        }}
        nextBestAction={{
          headline: "Engage Dynamic Rule Matching at AED 1,075 & Submit Amazon Brand Registry MAP Violation",
          description: "Match competitor floor dynamically while retaining healthy 27.4% net margin, and file an unauthorized reseller claim via Amazon Brand Protection portal.",
          actionTitle: "Match Price & Protect Margin",
          actionType: "pricing_match",
          estimatedLift: "+21 pp Buy Box Recovery",
          onExecute: () => onExecuteAction(`Matched Lowest Price at ${formatCurrency(activeProduct.lowestCompetitorPrice, currency)} for ${activeProduct.name}`, 'reprice'),
        }}
        plainSellerWords={{
          summary: "Rival shops have set their software to automatically undercut your price by a few dirhams. On 4 of your items, they are selling cheaper than you by AED 14 to AED 50. Every day you wait to match them, you lose about AED 1,420 in profit to them.",
          actionTip: "Lower your price to match theirs down to AED 1,075 (you will still make a solid 27% profit), and report any unauthorized discount sellers to Amazon Brand Protection.",
        }}
      />
    </div>
  );
};
