import React, { useState } from 'react';
import { 
  AlertTriangle, 
  ArrowDownRight, 
  ArrowUpRight, 
  Info, 
  ChevronRight, 
  ShieldAlert, 
  CheckCircle2, 
  Activity, 
  TrendingDown, 
  Layers,
  Calculator,
  X,
  HelpCircle,
  DollarSign,
  ShoppingCart,
  Tag
} from 'lucide-react';
import { Currency, DriverBreakdown, SellerHealthData, TimePeriod } from '../types/seller';
import { formatCurrency, formatPercent, formatPoints } from '../utils/formatters';
import { DashboardTranslations } from '../utils/translations';

interface SellerHealthScoreCardProps {
  healthData: SellerHealthData;
  timePeriod: TimePeriod;
  currency: Currency;
  onOpenRootCauseModal: () => void;
  onNavigateToModule: (moduleName: string) => void;
  translations?: DashboardTranslations;
  isSidebarMode?: boolean;
}

export const SellerHealthScoreCard: React.FC<SellerHealthScoreCardProps> = ({
  healthData,
  timePeriod,
  currency,
  onOpenRootCauseModal,
  onNavigateToModule,
  translations,
  isSidebarMode = false,
}) => {
  const [hoveredDriver, setHoveredDriver] = useState<string | null>(null);
  const [isScoreModalOpen, setIsScoreModalOpen] = useState<boolean>(false);
  const [isRevenueModalOpen, setIsRevenueModalOpen] = useState<boolean>(false);

  const {
    overallScore,
    scoreDelta,
    totalRevenue,
    revenueDeltaPercent,
    revenueAtRisk,
    issuesCount,
    primaryConcern,
    drivers,
  } = healthData;

  const t = translations;

  const driverList: { key: string; name: string; data: DriverBreakdown; targetModule: string }[] = [
    { key: 'buyBox', name: t?.driverBuyBox || drivers.buyBox.name, data: drivers.buyBox, targetModule: 'buybox' },
    { key: 'searchVisibility', name: t?.driverSearch || drivers.searchVisibility.name, data: drivers.searchVisibility, targetModule: 'search' },
    { key: 'inventory', name: t?.driverInventory || drivers.inventory.name, data: drivers.inventory, targetModule: 'inventory' },
    { key: 'conversion', name: t?.driverConversion || drivers.conversion.name, data: drivers.conversion, targetModule: 'conversion' },
    { key: 'pricing', name: t?.driverPricing || drivers.pricing.name, data: drivers.pricing, targetModule: 'pricing' },
  ];

  // Radial progress calculations
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (overallScore / 100) * circumference;

  const isScoreDropping = scoreDelta < 0;

  // Revenue decomposition math (Orders x Price)
  const currentOrders = timePeriod === 'weekly' ? 235 : timePeriod === 'monthly' ? 987 : 3098;
  const previousOrders = timePeriod === 'weekly' ? 252 : timePeriod === 'monthly' ? 1078 : 2917;
  const currentAov = totalRevenue / currentOrders;
  const previousRev = totalRevenue / (1 + revenueDeltaPercent / 100);
  const previousAov = previousRev / previousOrders;
  const ordersDeltaPct = ((currentOrders - previousOrders) / previousOrders) * 100;
  const aovDeltaPct = ((currentAov - previousAov) / previousAov) * 100;

  return (
    <div className={`bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden transition-all ${isSidebarMode ? 'p-4' : 'p-6'}`}>
      {/* Top Banner with Diagnosis CTA */}
      <div className={`flex justify-between border-b border-slate-100 dark:border-slate-800 ${isSidebarMode ? 'flex-col gap-2.5 pb-3.5 mb-3.5' : 'flex-col lg:flex-row lg:items-center pb-5 mb-5 gap-4'}`}>
        <div>
          <div className="flex items-center gap-2">
            <h2 className={`${isSidebarMode ? 'text-lg' : 'text-xl'} font-bold tracking-tight text-slate-900 dark:text-white`}>
              {t?.sellerHealthTitle || 'Seller Revenue Health'}
            </h2>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              {t?.weightedIndexPill || '5 Pillars × 20%'}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
            {t?.sellerHealthSubtitle || 'Synthesized from Amazon Seller Central performance and competitive Buy Box & Search algorithms'}
          </p>
        </div>

        {/* Drill-down breadcrumb trigger */}
        <button
          onClick={onOpenRootCauseModal}
          className="group flex items-center justify-between gap-2 px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-bold hover:bg-amber-400 transition-all shadow-md shadow-amber-500/20 cursor-pointer self-start lg:self-auto w-full sm:w-auto"
        >
          <div className="flex items-center gap-1 text-[10px] font-semibold text-slate-900">
            <span>Seller</span>
            <ChevronRight className="w-2.5 h-2.5" />
            <span>Product</span>
            <ChevronRight className="w-2.5 h-2.5" />
            <span>Search Term</span>
          </div>
          <span className="bg-slate-950 text-amber-400 px-1.5 py-0.5 rounded text-[10px] font-bold group-hover:scale-105 transition-transform">
            {t?.diagnoseWhy || 'Diagnose Why'}
          </span>
        </button>
      </div>

      {/* Main Grid: Score Gauge + High Level Financials + Drivers Breakdown */}
      <div className={isSidebarMode ? "flex flex-col space-y-4" : "grid grid-cols-1 md:grid-cols-12 gap-6 items-center"}>
        
        {/* Left: 0-100 Gauge */}
        <div className={isSidebarMode ? "w-full flex flex-col items-center justify-center p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800" : "md:col-span-3 flex flex-col items-center justify-center p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800"}>
          <div className="relative w-36 h-36 flex items-center justify-center">
            {/* Background SVG circle */}
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 130 130">
              <circle
                cx="65"
                cy="65"
                r={radius}
                className="stroke-slate-200 dark:stroke-slate-700"
                strokeWidth="10"
                fill="transparent"
              />
              <circle
                cx="65"
                cy="65"
                r={radius}
                stroke="currentColor"
                strokeWidth="10"
                fill="transparent"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                className={`transition-all duration-1000 ease-out ${
                  overallScore >= 80 
                    ? 'text-emerald-500' 
                    : overallScore >= 70 
                    ? 'text-amber-500' 
                    : 'text-rose-500'
                }`}
              />
            </svg>

            {/* Score inside dial */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                {overallScore}
              </span>
              <span className="text-xs font-semibold text-slate-400">/ 100 pts</span>
              
              <div className={`flex items-center gap-1 text-[11px] font-bold mt-0.5 ${
                isScoreDropping ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'
              }`}>
                {isScoreDropping ? (
                  <ArrowDownRight className="w-3.5 h-3.5" />
                ) : (
                  <ArrowUpRight className="w-3.5 h-3.5" />
                )}
                <span>{healthData.previousScore} → {overallScore} ({scoreDelta > 0 ? `+${scoreDelta}` : scoreDelta} pts)</span>
              </div>
            </div>
          </div>

          <div className="mt-2 text-center w-full">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 block mb-1.5">
              Status: {overallScore >= 80 ? (t?.statusHealthy || 'Healthy') : overallScore >= 70 ? (t?.statusActionNeeded || 'Action Needed') : (t?.statusCritical || 'Critical')}
            </span>

            {/* Quick Note & Formula Breakdown Button */}
            <button
              onClick={() => setIsScoreModalOpen(true)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 dark:text-amber-400 border border-amber-300 dark:border-amber-800 text-[11px] font-bold transition-all cursor-pointer shadow-2xs"
            >
              <Calculator className="w-3 h-3 text-amber-500" />
              <span>{t?.whyScoreButton || `Why ${overallScore} pts? Formula`}</span>
            </button>
          </div>
        </div>

        {/* Center: Financials & At Risk stats */}
        <div className={isSidebarMode ? "w-full flex flex-col space-y-3" : "md:col-span-4 flex flex-col justify-between space-y-4"}>
          
          {/* Revenue Tile (Double-click enabled for Orders x Price breakdown) */}
          <div 
            onDoubleClick={() => setIsRevenueModalOpen(true)}
            className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 hover:border-amber-500/40 transition-colors cursor-pointer group relative"
            title="Double-click to view Orders x Price breakdown and why the 12% drop happened"
          >
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                {t?.totalMarketplaceRev || 'Total Marketplace Revenue'}
              </span>
              <span className="text-[11px] font-medium text-slate-400">
                {t?.vsPrevPeriod || 'vs prev period'}
              </span>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-slate-900 dark:text-white">
                {formatCurrency(totalRevenue, currency)}
              </span>
              <span className={`text-xs font-bold flex items-center ${
                revenueDeltaPercent < 0 ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400'
              }`}>
                {revenueDeltaPercent < 0 ? <ArrowDownRight className="w-3 h-3 mr-0.5" /> : <ArrowUpRight className="w-3 h-3 mr-0.5" />}
                {formatPercent(revenueDeltaPercent)}
              </span>
            </div>

            <div className="mt-2 pt-2 border-t border-slate-200/60 dark:border-slate-800 flex items-center justify-between text-[10.5px]">
              <span className="text-amber-600 dark:text-amber-400 font-semibold group-hover:underline flex items-center gap-1">
                <span>{t?.doubleClickRevenueHint || '💡 Double-click for Orders × Price math'}</span>
              </span>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setIsRevenueModalOpen(true);
                }}
                className="text-[10px] text-slate-400 hover:text-slate-200 underline font-medium"
              >
                Inspect Math
              </button>
            </div>
          </div>

          {/* Revenue at Risk */}
          <div className="p-3.5 rounded-xl bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200/80 dark:border-rose-900/40">
            <div className="flex items-center justify-between text-xs text-rose-800 dark:text-rose-300 mb-1">
              <span className="font-semibold flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                {t?.revAtRisk || 'Revenue at Risk'}
              </span>
              <span className="text-[11px] font-bold text-rose-700 dark:text-rose-400 bg-rose-100 dark:bg-rose-900/50 px-1.5 py-0.5 rounded">
                {issuesCount} {t?.issuesNeedAttention || 'issues need attention'}
              </span>
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-extrabold text-rose-600 dark:text-rose-400">
                {formatCurrency(revenueAtRisk, currency)}
              </span>
              <span className="text-xs text-rose-700 dark:text-rose-300 font-medium truncate max-w-[180px]">
                {t?.primaryConcernPrefix || 'Primary:'} <strong className="underline">{primaryConcern}</strong>
              </span>
            </div>
          </div>

        </div>

        {/* Right: Driver Waterfall (Click driver to jump directly to section on All Modules) */}
        <div className={isSidebarMode ? "w-full flex flex-col space-y-2 pt-1" : "md:col-span-5 flex flex-col justify-between"}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-amber-500" />
              {t?.whatsDrivingChange || "What's Driving The Change?"}
            </span>
            <span className="text-[11px] text-amber-600 dark:text-amber-400 font-medium">
              {t?.clickDriverToJump || 'Click driver to jump to section ↓'}
            </span>
          </div>

          <div className="space-y-2">
            {driverList.map(({ key, name, data, targetModule }) => {
              const isNegative = data.deltaPts < 0;
              const isHovered = hoveredDriver === key;

              return (
                <div
                  key={key}
                  onMouseEnter={() => setHoveredDriver(key)}
                  onMouseLeave={() => setHoveredDriver(null)}
                  onClick={() => onNavigateToModule(targetModule)}
                  className={`group p-2.5 rounded-xl border transition-all cursor-pointer ${
                    isHovered
                      ? 'bg-slate-100 dark:bg-slate-800 border-amber-500 shadow-sm translate-x-1'
                      : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200/70 dark:border-slate-800 hover:border-amber-400'
                  }`}
                  title={`Jump to ${name} module`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-sm">
                        {isNegative ? '🔴' : '🟢'}
                      </span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 group-hover:text-amber-500 transition-colors">
                        {name}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        (20% wt)
                      </span>
                      {data.primaryConcern && (
                        <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded bg-rose-500 text-white">
                          {t?.primaryLoss || 'Primary Loss'}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {data.prevScore !== undefined && (
                        <span className="text-[11px] font-mono text-slate-400 dark:text-slate-400">
                          {data.prevScore} → <strong className="text-slate-700 dark:text-slate-200">{data.score}</strong>
                        </span>
                      )}
                      <span className={`font-bold px-1.5 py-0.5 rounded text-[11px] ${
                        isNegative 
                          ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400' 
                          : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                      }`}>
                        {formatPoints(data.deltaPts)}
                      </span>
                      <span className="text-xs text-slate-400 group-hover:text-amber-500 transition-colors">
                        ↓
                      </span>
                    </div>
                  </div>

                  {/* Interactive detail when hovered or active concern */}
                  {(isHovered || data.primaryConcern) && (
                    <p className="mt-1.5 text-[11px] text-slate-600 dark:text-slate-300 pl-6 leading-relaxed">
                      {data.insight}
                    </p>
                  )}
                </div>
              );
            })}
          </div>

        </div>

      </div>

      {/* MODAL 1: Why 78 Points - Absolute Number & Formula Breakdown */}
      {isScoreModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center font-bold">
                  <Calculator className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Why {overallScore} Points? Formula & Calculation
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Transparent mathematical decomposition of your Seller Health Index
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsScoreModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Note on Absolute Number */}
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-1.5">
              <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-sky-500" />
                The Absolute Number: {overallScore} out of 100 Possible Points
              </span>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                The score of <strong>{overallScore} points</strong> represents your store's composite operational and competitive health across the UAE marketplace. It is not an arbitrary grade; it is an index synthesized from 5 independent performance pillars, each contributing up to <strong>20 points</strong> (Total = 100 points).
              </p>
            </div>

            {/* 5 Pillars Mathematical Breakdown */}
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Pillar Weightings & Exact Scores (Sum = {overallScore} pts)
              </span>

              <div className="border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                <div className="p-2.5 flex items-center justify-between bg-rose-50/30 dark:bg-rose-950/10">
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">1. Buy Box Performance (20% Weight)</span>
                    <p className="text-[11px] text-slate-500">Suffered 18 peak lost hours due to rival undercuts</p>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-rose-600 dark:text-rose-400 font-mono text-sm">{drivers.buyBox.score} / 20</span>
                    <span className="text-[10px] text-slate-400 block">was 20 (-9 pts)</span>
                  </div>
                </div>

                <div className="p-2.5 flex items-center justify-between bg-rose-50/30 dark:bg-rose-950/10">
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">2. Search Visibility (20% Weight)</span>
                    <p className="text-[11px] text-slate-500">Organic head terms slipped from Rank #3 to Rank #11</p>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-rose-600 dark:text-rose-400 font-mono text-sm">{drivers.searchVisibility.score} / 20</span>
                    <span className="text-[10px] text-slate-400 block">was 18 (-6 pts)</span>
                  </div>
                </div>

                <div className="p-2.5 flex items-center justify-between bg-amber-50/30 dark:bg-amber-950/10">
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">3. Inventory Stock Level (20% Weight)</span>
                    <p className="text-[11px] text-slate-500">Sony XM5 & Ninja Air Fryer breached &lt;30 DOC threshold</p>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-amber-600 dark:text-amber-400 font-mono text-sm">{drivers.inventory.score} / 20</span>
                    <span className="text-[10px] text-slate-400 block">was 19 (-4 pts)</span>
                  </div>
                </div>

                <div className="p-2.5 flex items-center justify-between bg-emerald-50/30 dark:bg-emerald-950/10">
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">4. Conversion Rate (20% Weight)</span>
                    <p className="text-[11px] text-slate-500">Enhanced A+ comparison charts lifted listing conversion</p>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-emerald-600 dark:text-emerald-400 font-mono text-sm">{drivers.conversion.score} / 20</span>
                    <span className="text-[10px] text-slate-400 block">was 16 (+2 pts)</span>
                  </div>
                </div>

                <div className="p-2.5 flex items-center justify-between bg-amber-50/30 dark:bg-amber-950/10">
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">5. Competitive Pricing (20% Weight)</span>
                    <p className="text-[11px] text-slate-500">Price disparity on 4 out of 10 SKUs leaking margins</p>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-amber-600 dark:text-amber-400 font-mono text-sm">{drivers.pricing.score} / 20</span>
                    <span className="text-[10px] text-slate-400 block">was 18 (-2 pts)</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Total Formula Equation */}
            <div className="p-3 rounded-xl bg-slate-900 text-white dark:bg-slate-950 border border-slate-800 flex items-center justify-between">
              <span className="text-xs font-mono text-amber-300">
                Formula: 11 + 12 + 15 + 18 + 16
              </span>
              <span className="text-sm font-extrabold text-white">
                = {overallScore} / 100 Points ({scoreDelta} pts vs prev)
              </span>
            </div>

            <div className="pt-1 flex justify-end">
              <button
                onClick={() => setIsScoreModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-950 text-xs font-bold cursor-pointer transition-colors"
              >
                Understood
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Marketplace Revenue Decomposition: Orders x Price & Why 12% Drop Happened */}
      {isRevenueModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-rose-500/10 text-rose-500 flex items-center justify-center font-bold">
                  <DollarSign className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    {t?.revenueDecompTitle || 'Marketplace Revenue Decomposition: Orders × Price'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Mathematical proof of why your revenue dropped by -12.0%
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsRevenueModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Core Formula Box */}
            <div className="p-3.5 rounded-xl bg-slate-900 text-white dark:bg-slate-950 border border-slate-800 text-xs font-mono space-y-1">
              <div className="text-amber-400 font-bold">
                {t?.revenueFormula || 'Revenue = Total Orders × Average Selling Price (ASP)'}
              </div>
              <div className="text-slate-300 text-[11.5px]">
                Current: {currentOrders.toLocaleString()} Orders × {formatCurrency(currentAov, currency)} = {formatCurrency(totalRevenue, currency)}
              </div>
              <div className="text-slate-400 text-[11.5px]">
                Previous: {previousOrders.toLocaleString()} Orders × {formatCurrency(previousAov, currency)} = {formatCurrency(previousRev, currency)}
              </div>
            </div>

            {/* Why Did the 12% Drop Happen? (Root Cause Explanation) */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400 flex items-center gap-1.5">
                <TrendingDown className="w-3.5 h-3.5" />
                {t?.why12DropTitle || 'Why Did the 12% Drop Happen? (Detailed Root Cause)'}
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {/* 1. Order Volume Drop */}
                <div className="p-3 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/40 dark:bg-rose-950/20 space-y-1">
                  <div className="flex items-center justify-between font-bold text-rose-700 dark:text-rose-300">
                    <span className="flex items-center gap-1">
                      <ShoppingCart className="w-3.5 h-3.5" />
                      1. Order Volume Drop
                    </span>
                    <span>{formatPercent(ordersDeltaPct)}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                    You received <strong>{previousOrders - currentOrders} fewer orders</strong> ({currentOrders} vs {previousOrders}). 
                    Why? Losing the Buy Box for 18 peak traffic hours meant Amazon handed buyer checkouts directly to rival 3P undercutters.
                  </p>
                </div>

                {/* 2. Basket / ASP Compression */}
                <div className="p-3 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/40 dark:bg-amber-950/20 space-y-1">
                  <div className="flex items-center justify-between font-bold text-amber-700 dark:text-amber-300">
                    <span className="flex items-center gap-1">
                      <Tag className="w-3.5 h-3.5" />
                      2. Price / ASP Erosion
                    </span>
                    <span>{formatPercent(aovDeltaPct)}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                    Average revenue per order slipped from <strong>{formatCurrency(previousAov, currency)}</strong> to <strong>{formatCurrency(currentAov, currency)}</strong>.
                    Why? Price cuts on flagship audio (Sony XM5) and computer accessories dragged down the average order basket value.
                  </p>
                </div>
              </div>

              {/* Compounding Effect */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                <strong>The Compounding Math:</strong> -6.7% fewer customer orders combined with a -5.6% drop in average price per transaction resulted in the exact <strong>-12.0% Total Marketplace Revenue Drop</strong> ({formatCurrency(totalRevenue - previousRev, currency)} net revenue loss).
              </div>
            </div>

            <div className="pt-2 flex justify-between items-center border-t border-slate-100 dark:border-slate-800">
              <span className="text-[11px] text-slate-400">
                Action: Re-anchor Buy Box price at AED 1,075 to restore volume.
              </span>
              <button
                onClick={() => setIsRevenueModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-950 text-xs font-bold cursor-pointer transition-colors"
              >
                Close Explanation
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
